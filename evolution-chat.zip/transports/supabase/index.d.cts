import { SupabaseClient } from '@supabase/supabase-js';

type ChatMessageDirection = "visitor" | "owner" | "system";
type ChatMessageStatus = "pending" | "sent" | "failed";
type ChatSessionStatus = "active" | "closed" | "failed";
/** Mensagem persistida (domínio). */
interface ChatMessage {
    id: string;
    sessionId: string;
    direction: ChatMessageDirection;
    body: string;
    status: ChatMessageStatus;
    waMessageId: string | null;
    createdAt: string;
}
/** Evento de tempo real publicado no canal broadcast `chat:<realtimeToken>`. */
type ChatEvent = {
    type: "message";
    message: ChatMessage;
} | {
    type: "session";
    status: ChatSessionStatus;
}
/** Indicador de digitação: `from` diz quem está digitando (dona da plataforma
 *  ou visitante) para o widget exibir os "3 pontinhos" apenas quando a OUTRA
 *  ponta digita. */
 | {
    type: "typing";
    isTyping: boolean;
    from: "owner" | "visitor";
};

/** Publicação server-side de eventos para o canal de uma sessão (fire-and-forget). */
interface RealtimeTransport {
    publish(realtimeToken: string, event: ChatEvent): Promise<void>;
}
/**
 * Assinatura client-side do mesmo canal (usada pelo widget — Task 9).
 * `subscribe` devolve o unsubscribe; `onStatus` reporta conexão do transporte.
 */
interface RealtimeHandle {
    subscribe(realtimeToken: string, onEvent: (e: ChatEvent) => void, onStatus?: (s: "open" | "closed") => void): () => void;
}

/** Test-only: esvazia o cache de clientes entre testes. */
declare function __resetRealtimeClientCache(): void;
/** Publica `event` no canal broadcast da sessão. Rejeita se o broadcast não for aceito. */
declare function createSupabaseTransport(admin: SupabaseClient): RealtimeTransport;
/**
 * Handle client-side (widget): `subscribe(token, onEvent, onStatus?)` assina
 * `chat:<token>` e devolve o unsubscribe. O client é criado uma única vez na fábrica.
 */
declare function createSupabaseRealtimeHandle(url: string, anonKey: string): RealtimeHandle;

export { __resetRealtimeClientCache, createSupabaseRealtimeHandle, createSupabaseTransport };
