"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/transports/supabase/index.ts
var supabase_exports = {};
__export(supabase_exports, {
  __resetRealtimeClientCache: () => __resetRealtimeClientCache,
  createSupabaseRealtimeHandle: () => createSupabaseRealtimeHandle,
  createSupabaseTransport: () => createSupabaseTransport
});
module.exports = __toCommonJS(supabase_exports);
var import_supabase_js = require("@supabase/supabase-js");
var CHANNEL_PREFIX = "chat:";
var BROADCAST_EVENT = "chat";
var channelName = (realtimeToken) => `${CHANNEL_PREFIX}${realtimeToken}`;
var clientCache = /* @__PURE__ */ new Map();
function getRealtimeClient(url, anonKey) {
  const cached = clientCache.get(url);
  if (cached) return cached;
  const client = (0, import_supabase_js.createClient)(url, anonKey, {
    auth: {
      // O widget só assina um canal broadcast público: não precisa de sessão persistida,
      // nem de refresh de token, nem de ler a URL. Desligar o persist + usar storageKey
      // próprio garante que este client NÃO concorra com o auth do app pela mesma chave.
      persistSession: false,
      autoRefreshToken: false,
      detectSessionInUrl: false,
      storageKey: "evolution-chat-realtime"
    }
  });
  clientCache.set(url, client);
  return client;
}
function __resetRealtimeClientCache() {
  clientCache.clear();
}
var STATUS_BY_REALTIME_STATE = {
  SUBSCRIBED: "open",
  CHANNEL_ERROR: "closed",
  TIMED_OUT: "closed",
  CLOSED: "closed"
};
function createSupabaseTransport(admin) {
  return {
    async publish(realtimeToken, event) {
      const channel = channelName(realtimeToken);
      const response = await admin.channel(channel).send({
        type: "broadcast",
        event: BROADCAST_EVENT,
        payload: event
      });
      if (response !== "ok") {
        throw new Error(`Supabase broadcast "${channel}" n\xE3o entregue: ${response}`);
      }
    }
  };
}
function createSupabaseRealtimeHandle(url, anonKey) {
  const client = getRealtimeClient(url, anonKey);
  return {
    subscribe(realtimeToken, onEvent, onStatus) {
      const channel = client.channel(channelName(realtimeToken));
      channel.on("broadcast", { event: BROADCAST_EVENT }, (message) => {
        onEvent(message.payload);
      });
      channel.subscribe((status) => {
        onStatus?.(STATUS_BY_REALTIME_STATE[status] ?? "closed");
      });
      return () => {
        void channel.unsubscribe();
      };
    }
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  __resetRealtimeClientCache,
  createSupabaseRealtimeHandle,
  createSupabaseTransport
});
//# sourceMappingURL=index.cjs.map