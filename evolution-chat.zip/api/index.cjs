"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/api/index.ts
var api_exports = {};
__export(api_exports, {
  EvolutionApiError: () => EvolutionApiError,
  createEvolutionClient: () => createEvolutionClient,
  generateRealtimeToken: () => generateRealtimeToken,
  generateSessionCode: () => generateSessionCode,
  isValidPhone: () => isValidPhone,
  normalizePhone: () => normalizePhone,
  parseWebhookEvent: () => parseWebhookEvent,
  toWhatsappJid: () => toWhatsappJid
});
module.exports = __toCommonJS(api_exports);

// src/errors.ts
var ChatError = class extends Error {
  code;
  cause;
  constructor(message, code, cause) {
    super(message);
    this.name = "ChatError";
    this.code = code;
    this.cause = cause;
  }
};

// src/api/phone.ts
var NON_DIGITS = /\D+/g;
function normalizePhone(raw, defaultDdi = "55") {
  const digits = raw.replace(NON_DIGITS, "");
  if (!digits) throw new ChatError("Telefone vazio", "invalid_input");
  const explicitDdi = raw.includes("+");
  const withDdi = digits.length <= 11 && !explicitDdi && !digits.startsWith(defaultDdi) ? defaultDdi + digits : digits;
  if (withDdi.length < 10 || withDdi.length > 15) {
    throw new ChatError("Telefone inv\xE1lido", "invalid_input");
  }
  return withDdi;
}
function isValidPhone(digits) {
  return digits.length >= 10 && digits.length <= 15;
}
function toWhatsappJid(phoneDigits) {
  return `${phoneDigits}@s.whatsapp.net`;
}

// src/api/ids.ts
var SESSION_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
var SESSION_CODE_LENGTH = 4;
var SESSION_ACCEPT_LIMIT = 256 - 256 % SESSION_ALPHABET.length;
var BASE64URL_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
var TOKEN_BYTES = 24;
function randomChar(alphabet, acceptLimit) {
  const buffer = new Uint8Array(1);
  for (; ; ) {
    globalThis.crypto.getRandomValues(buffer);
    const byte = buffer[0];
    if (byte !== void 0 && byte < acceptLimit) {
      return alphabet.charAt(byte % alphabet.length);
    }
  }
}
function generateSessionCode() {
  return Array.from({ length: SESSION_CODE_LENGTH }, () => randomChar(SESSION_ALPHABET, SESSION_ACCEPT_LIMIT)).join("");
}
function generateRealtimeToken() {
  const bytes = new Uint8Array(TOKEN_BYTES);
  globalThis.crypto.getRandomValues(bytes);
  let token = "";
  let acc = 0;
  let bits = 0;
  for (const byte of bytes) {
    acc = acc << 8 | byte;
    bits += 8;
    while (bits >= 6) {
      bits -= 6;
      token += BASE64URL_ALPHABET.charAt(acc >>> bits & 63);
    }
  }
  return token;
}

// src/api/client.ts
var EvolutionApiError = class extends Error {
  constructor(status, body, operation) {
    super(`Evolution ${operation} falhou (${status})`);
    this.status = status;
    this.body = body;
    this.name = "EvolutionApiError";
  }
  status;
  body;
};
function readPath(json, ...path) {
  let cur = json;
  for (const key of path) {
    if (!cur || typeof cur !== "object") return void 0;
    cur = cur[key];
  }
  return cur;
}
function createEvolutionClient(cfg) {
  const doFetch = cfg.fetchImpl ?? fetch;
  const base = cfg.baseUrl.replace(/\/+$/, "");
  const headers = { "content-type": "application/json", apikey: cfg.apiKey };
  async function request(operation, method, path, body) {
    const response = await doFetch(`${base}${path}`, {
      method,
      headers,
      ...body === void 0 ? {} : { body: JSON.stringify(body) }
    });
    if (!response.ok) throw new EvolutionApiError(response.status, await response.text(), operation);
    return response;
  }
  async function requestJson(operation, method, path, body) {
    const response = await request(operation, method, path, body);
    const text = await response.text();
    let parsed;
    try {
      parsed = JSON.parse(text);
    } catch {
      throw new EvolutionApiError(response.status, text, operation);
    }
    if (!parsed || typeof parsed !== "object") throw new EvolutionApiError(response.status, text, operation);
    return { operation, status: response.status, text, json: parsed };
  }
  function requireString(res, ...path) {
    const value = readPath(res.json, ...path);
    if (typeof value !== "string" || value === "") throw new EvolutionApiError(res.status, res.text, res.operation);
    return value;
  }
  async function fetchConnectionState(instance) {
    const res = await requestJson("getConnectionState", "GET", `/instance/connectionState/${instance}`);
    const state = readPath(res.json, "instance", "state");
    if (state === "open" || state === "connecting" || state === "close") return state;
    throw new EvolutionApiError(res.status, res.text, res.operation);
  }
  return {
    async sendText(instance, number, text) {
      const res = await requestJson("sendText", "POST", `/message/sendText/${instance}`, { number, text });
      return { waMessageId: requireString(res, "key", "id") };
    },
    async sendPresence(instance, number, presence) {
      await request("sendPresence", "POST", `/message/sendPresence/${instance}`, {
        number,
        presence
      });
    },
    async createGroup(instance, subject, participants, description) {
      const payload = description === void 0 ? { subject, participants } : { subject, participants, description };
      const res = await requestJson("createGroup", "POST", `/group/create/${instance}`, payload);
      const groupJid = readPath(res.json, "group", "id") ?? res.json.id;
      if (typeof groupJid !== "string" || groupJid === "") {
        throw new ChatError("Evolution createGroup: groupJid ausente/inv\xE1lido na resposta", "send_failed");
      }
      return { groupJid };
    },
    async setGroupPicture(instance, groupJid, image) {
      await request("setGroupPicture", "POST", `/group/updateGroupPicture/${instance}`, { groupJid, image });
    },
    async leaveGroup(instance, groupJid) {
      await request("leaveGroup", "DELETE", `/group/leave/${instance}`, { groupId: groupJid });
    },
    async logout(instance) {
      await request("logout", "DELETE", `/instance/logout/${instance}`);
    },
    async getConnectionState(instance) {
      return fetchConnectionState(instance);
    },
    async connectQR(instance) {
      const res = await requestJson("connectQR", "GET", `/instance/connect/${instance}`);
      const base64 = readPath(res.json, "base64");
      const pairingCode = readPath(res.json, "pairingCode");
      const code = readPath(res.json, "code");
      return {
        qrBase64: typeof base64 === "string" ? base64 : null,
        pairingCode: typeof pairingCode === "string" ? pairingCode : typeof code === "string" ? code : null
      };
    },
    async createInstance(instance, integration = "WHATSAPP-BAILEYS") {
      await request("createInstance", "POST", "/instance/create", { instanceName: instance, integration });
    },
    async ensureInstance(instance) {
      try {
        await fetchConnectionState(instance);
        return;
      } catch {
      }
      await this.createInstance(instance);
    },
    async setWebhook(instance, url, events) {
      await request("setWebhook", "POST", `/webhook/set/${instance}`, {
        webhook: { enabled: true, url, events, webhookByEvents: true, webhookBase64: false }
      });
    }
  };
}

// src/api/webhook-parser.ts
function isRecord(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function textFromMessage(message) {
  if (!isRecord(message)) return null;
  const conversation = message["conversation"];
  if (typeof conversation === "string") {
    const trimmed = conversation.trim();
    return trimmed.length > 0 ? trimmed : null;
  }
  const extended = message["extendedTextMessage"];
  if (isRecord(extended)) {
    const text = extended["text"];
    if (typeof text === "string") {
      const trimmed = text.trim();
      return trimmed.length > 0 ? trimmed : null;
    }
  }
  return null;
}
function timestampSeconds(value) {
  const seconds = typeof value === "number" ? value : typeof value === "string" ? Number(value) : Number.NaN;
  return Number.isFinite(seconds) ? Math.floor(seconds) : 0;
}
function parseMessageItem(item) {
  if (!isRecord(item)) return { kind: "ignored", reason: "messages.upsert sem data v\xE1lido" };
  const key = isRecord(item["key"]) ? item["key"] : null;
  const waMessageId = key?.["id"];
  const jid = key?.["remoteJid"];
  if (typeof waMessageId !== "string" || waMessageId.length === 0) {
    return { kind: "ignored", reason: "mensagem sem key.id" };
  }
  if (typeof jid !== "string" || jid.length === 0) {
    return { kind: "ignored", reason: "mensagem sem key.remoteJid" };
  }
  const text = textFromMessage(item["message"]);
  if (text === null) {
    return { kind: "ignored", reason: "mensagem sem texto (conversation/extendedTextMessage)" };
  }
  const senderJid = key?.["participant"];
  return {
    kind: "message",
    event: {
      waMessageId,
      jid,
      fromMe: key?.["fromMe"] === true,
      senderJid: typeof senderJid === "string" ? senderJid : null,
      text,
      timestamp: timestampSeconds(item["messageTimestamp"]),
      raw: item
    }
  };
}
function parseWebhookEvent(payload) {
  if (!isRecord(payload)) return { kind: "ignored", reason: "payload n\xE3o \xE9 um objeto" };
  const event = payload["event"];
  if (typeof event !== "string") return { kind: "ignored", reason: "payload sem campo event" };
  const data = payload["data"];
  if (event === "connection.update") {
    const state = isRecord(data) ? data["state"] : void 0;
    if (typeof state === "string" && state.length > 0) return { kind: "connection", state };
    return { kind: "ignored", reason: "connection.update sem state" };
  }
  if (event === "group-participants.update") {
    return parseGroupParticipants(data);
  }
  if (event === "PRESENCE_UPDATE" || event === "presence.update") {
    return parsePresence(data);
  }
  if (event !== "messages.upsert") {
    return { kind: "ignored", reason: `evento n\xE3o tratado: ${event}` };
  }
  const items = Array.isArray(data) ? data : [data];
  let lastIgnored = { kind: "ignored", reason: "messages.upsert sem data v\xE1lido" };
  for (const item of items) {
    const parsed = parseMessageItem(item);
    if (parsed.kind !== "ignored") return parsed;
    lastIgnored = parsed;
  }
  return lastIgnored;
}
function parseGroupParticipants(data) {
  if (!isRecord(data)) return { kind: "ignored", reason: "group-participants sem data" };
  const groupJid = data["id"];
  if (typeof groupJid !== "string" || groupJid.length === 0) {
    return { kind: "ignored", reason: "group-participants sem id (groupJid)" };
  }
  const rawParticipants = data["participants"];
  if (!Array.isArray(rawParticipants)) {
    return { kind: "ignored", reason: "group-participants sem participants[]" };
  }
  const participants = [];
  for (const p of rawParticipants) {
    if (typeof p === "string" && p.length > 0) participants.push(p);
  }
  if (participants.length === 0) {
    return { kind: "ignored", reason: "group-participants sem participantes v\xE1lidos" };
  }
  const actionRaw = data["action"];
  const action = typeof actionRaw === "string" ? actionRaw : "unknown";
  const authorRaw = data["author"];
  const author = typeof authorRaw === "string" ? authorRaw : null;
  return {
    kind: "group_participants",
    event: { groupJid, participants, action, author, raw: data }
  };
}
function parsePresence(data) {
  if (!isRecord(data)) return { kind: "ignored", reason: "presence sem data" };
  const groupJid = typeof data["id"] === "string" && data["id"] ? data["id"] : null;
  let participantJid = null;
  let presenceRaw = null;
  const presences = data["presences"];
  if (isRecord(presences)) {
    const entries = Object.entries(presences);
    const first = entries[0];
    if (first !== void 0) {
      const [jid, info] = first;
      participantJid = jid;
      presenceRaw = isRecord(info) ? info["presence"] ?? info["lastKnownPresence"] : info;
    }
  } else {
    participantJid = typeof data["participant"] === "string" ? data["participant"] : null;
    presenceRaw = data["presence"] ?? data["lastKnownPresence"];
  }
  const presence = normalizePresence(presenceRaw);
  if (presence === null) return { kind: "ignored", reason: "presence sem estado reconhec\xEDvel" };
  return {
    kind: "presence",
    event: { groupJid, participantJid, presence, raw: data }
  };
}
function normalizePresence(value) {
  if (value === "composing" || value === "recording") return value;
  if (value === "paused") return "paused";
  if (value === "available" || value === "unavailable") return "paused";
  return null;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  EvolutionApiError,
  createEvolutionClient,
  generateRealtimeToken,
  generateSessionCode,
  isValidPhone,
  normalizePhone,
  parseWebhookEvent,
  toWhatsappJid
});
//# sourceMappingURL=index.cjs.map