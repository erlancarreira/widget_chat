declare function normalizePhone(raw: string, defaultDdi?: string): string;
declare function isValidPhone(digits: string): boolean;
declare function toWhatsappJid(phoneDigits: string): string;

declare function generateSessionCode(): string;
declare function generateRealtimeToken(): string;

/** Estado de presença (digitação) normalizado da Evolution. */
type PresenceState = "composing" | "paused" | "recording";
/**
 * Mensagem de entrada normalizada do webhook da Evolution, independente do
 * formato bruto do payload.
 */
interface InboundMessage {
    waMessageId: string;
    jid: string;
    fromMe: boolean;
    senderJid: string | null;
    text: string | null;
    timestamp: number;
    raw: unknown;
}
/**
 * Mudança de participantes em um grupo WhatsApp, normalizada a partir do evento
 * `group-participants.update` da Evolution API. Usada para notificar no chat quando
 * alguém entra, sai ou é removido/adicionado ao grupo da sessão.
 */
interface GroupParticipantChange {
    /** JID do grupo (ex.: "120363000000000001@g.us"). */
    groupJid: string;
    /** JIDs dos participantes afetados (ex.: ["5511999998888@s.whatsapp.net"]). */
    participants: string[];
    /** Ação da Evolution: "add" | "remove" | "leave" | "promote" | "demote". */
    action: "add" | "remove" | "leave" | "promote" | "demote" | (string & {});
    /** Quem executou a ação (JID); nulo para "leave" (o próprio participante saiu). */
    author: string | null;
    raw: unknown;
}
/**
 * Mudança de presença (digitação) normalizada do evento `PRESENCE_UPDATE` da
 * Evolution API. Usada para mostrar o indicador "digitando…" no widget quando a
 * outra ponta (dona da plataforma ou visitante) está compondo mensagem.
 *
 * - `groupJid`: JID do grupo (modo grupo) ou nulo (modo direto 1:1, em que o
 *   próprio número da plataforma é a conversa).
 * - `participantJid`: quem está digitando (em grupo, o participante específico;
 *   em direto, costuma vir nulo e tratamos como a dona da plataforma).
 * - `presence`: "composing"/"recording" = está digitando; "paused" = parou.
 */
interface PresenceChange {
    groupJid: string | null;
    participantJid: string | null;
    presence: PresenceState;
    raw: unknown;
}

interface EvolutionFetch {
    (url: string, init: RequestInit): Promise<Response>;
}
interface SendTextResult {
    waMessageId: string;
}
interface CreateGroupResult {
    groupJid: string;
}
interface EvolutionClient {
    sendText(instance: string, number: string, text: string): Promise<SendTextResult>;
    /** Envia presença de digitação ("digitando…") para o número/grupo. `presence` =
     *  "composing" | "recording" (digitando) ou "paused" (parou). Best-effort: a
     *  presença é anunciada pela CONTA CONECTADA à instância, não por terceiros. */
    sendPresence(instance: string, number: string, presence: PresenceState): Promise<void>;
    createGroup(instance: string, subject: string, participants: string[], description?: string): Promise<CreateGroupResult>;
    setGroupPicture(instance: string, groupJid: string, image: string): Promise<void>;
    leaveGroup(instance: string, groupJid: string): Promise<void>;
    /** Encerra a sessão WhatsApp da instância (desvincula o dispositivo). */
    logout(instance: string): Promise<void>;
    getConnectionState(instance: string): Promise<"open" | "connecting" | "close">;
    connectQR(instance: string): Promise<{
        qrBase64: string | null;
        pairingCode: string | null;
    }>;
    setWebhook(instance: string, url: string, events: string[]): Promise<void>;
    /** Cria a instância na Evolution (one-time). Exige a apiKey com permissão de criação. */
    createInstance(instance: string, integration?: "WHATSAPP-BAILEYS" | "WHATSAPP-BUSINESS"): Promise<void>;
    /**
     * Garante que a instância existe (idempotente): se `getConnectionState` responde
     * (qualquer estado), não faz nada; só chama `createInstance` quando a leitura falha
     * (instância inexistente). Assim o LMS gerencia o ciclo de vida sem criar manualmente
     * na Evolution — o único passo humano é escanear o QR de pareamento.
     */
    ensureInstance(instance: string): Promise<void>;
}
declare class EvolutionApiError extends Error {
    readonly status: number;
    readonly body: string;
    constructor(status: number, body: string, operation: string);
}
declare function createEvolutionClient(cfg: {
    baseUrl: string;
    apiKey: string;
    fetchImpl?: EvolutionFetch;
}): EvolutionClient;

type ParsedWebhook = {
    kind: "message";
    event: InboundMessage;
} | {
    kind: "connection";
    state: string;
} | {
    kind: "group_participants";
    event: GroupParticipantChange;
} | {
    kind: "presence";
    event: PresenceChange;
} | {
    kind: "ignored";
    reason: string;
};
declare function parseWebhookEvent(payload: unknown): ParsedWebhook;

export { type CreateGroupResult, EvolutionApiError, type EvolutionClient, type EvolutionFetch, type InboundMessage, type ParsedWebhook, type SendTextResult, createEvolutionClient, generateRealtimeToken, generateSessionCode, isValidPhone, normalizePhone, parseWebhookEvent, toWhatsappJid };
