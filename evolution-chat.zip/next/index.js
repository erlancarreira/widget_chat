// src/errors.ts
var ChatError = class extends Error {
  code;
  cause;
  constructor(message, code, cause) {
    super(message);
    this.name = "ChatError";
    this.code = code;
    this.cause = cause;
  }
};

// src/next/chat-routes.ts
var POST_LIMIT = 30;
var POST_WINDOW_MS = 60 * 1e3;
function json(status, body) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json; charset=utf-8" }
  });
}
function asText(value) {
  return typeof value === "string" ? value : "";
}
function isFilled(value) {
  return typeof value === "string" && value.trim().length > 0;
}
async function readJsonBody(req) {
  let parsed;
  try {
    parsed = await req.json();
  } catch {
    throw new ChatError("JSON inv\xE1lido", "invalid_input");
  }
  if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed)) {
    throw new ChatError("O corpo da requisi\xE7\xE3o deve ser um objeto JSON", "invalid_input");
  }
  return parsed;
}
var FIELD_BY_LABEL = { Nome: "name", Mensagem: "message" };
function fieldFromMessage(message) {
  if (message.startsWith("Telefone")) return "phone";
  const label = /^(\w+) deve ter\b/.exec(message)?.[1];
  return label === void 0 ? null : FIELD_BY_LABEL[label] ?? null;
}
function statusForError(err) {
  const code = typeof err === "object" && err !== null && "code" in err ? err.code : void 0;
  const message = typeof err === "object" && err !== null && typeof err.message === "string" ? err.message : "";
  const text = message !== "" || typeof code !== "string" ? message : code;
  switch (code) {
    case "invalid_input": {
      const field = fieldFromMessage(text);
      return field === null ? { status: 422, error: text } : { status: 422, error: text, field };
    }
    case "rate_limited":
      return { status: 429, error: text };
    case "session_not_found":
      return { status: 404, error: text };
    case "session_closed":
      return { status: 409, error: text };
    case "group_create_failed":
    case "send_failed":
      return { status: 502, error: text };
    case "disabled":
      return { status: 404, error: "not_found" };
    case "unauthorized":
      return { status: 401, error: text };
    case "store_error":
      return { status: 502, error: text };
    default:
      return { status: 500, error: "erro interno" };
  }
}
function errorResponse(error) {
  const { status, error: message, field } = statusForError(error);
  if (status === 500) {
    console.error("[evolution-chat] erro inesperado na rota:", error);
    return json(500, { error: message });
  }
  const body = { error: message };
  if (field !== void 0) body["field"] = field;
  return json(status, body);
}
function createChatRoutes(deps) {
  const { bridge } = deps;
  const getIpHash = deps.getIpHash ?? (() => null);
  async function GET(req) {
    try {
      const url = new URL(req.url);
      const token = url.searchParams.get("token");
      if (token === null || token === "") {
        return json(400, { error: "token \xE9 obrigat\xF3rio" });
      }
      bridge.setConfig(await deps.getConfig());
      const after = url.searchParams.get("after");
      const { session, messages } = await bridge.history(token, after);
      if (session === null) return json(404, { error: "session_not_found" });
      return json(200, {
        session: { code: session.code, status: session.status, visitorName: session.visitorName },
        messages
      });
    } catch (error) {
      return errorResponse(error);
    }
  }
  async function POST(req) {
    let body;
    try {
      body = await readJsonBody(req);
    } catch (error) {
      return errorResponse(error);
    }
    try {
      const cfg = await deps.getConfig();
      bridge.setConfig(cfg);
      const token = asText(body["token"]);
      const ipHash = getIpHash(req);
      if (token === "") {
        if (!cfg.enabled) return json(404, { error: "not_found" });
        if (isFilled(body["honeypot"])) {
          return json(200, { session: { code: "XXXX", status: "closed" }, messages: [] });
        }
      }
      if (deps.limiter !== void 0 && ipHash !== null && ipHash !== "") {
        const result = await deps.limiter(ipHash, POST_LIMIT, POST_WINDOW_MS);
        if (!result.success) {
          return json(429, { error: "Muitas requisi\xE7\xF5es. Tente novamente em alguns minutos." });
        }
      }
      if (token !== "") {
        const message = await bridge.sendVisitorMessage(token, asText(body["message"]));
        return json(200, { message });
      }
      const { session, messages } = await bridge.startChat({
        name: asText(body["name"]),
        phone: asText(body["phone"]),
        message: asText(body["message"]),
        contact: typeof body["contact"] === "string" ? body["contact"] : null,
        ipHash,
        userAgent: req.headers.get("user-agent") ?? null,
        honeypot: typeof body["honeypot"] === "string" ? body["honeypot"] : null
      });
      return json(200, {
        session: {
          code: session.code,
          status: session.status,
          realtimeToken: session.realtimeToken,
          visitorName: session.visitorName
        },
        messages
      });
    } catch (error) {
      return errorResponse(error);
    }
  }
  return { GET, POST };
}
function createWebhookRoute(deps) {
  const { bridge } = deps;
  async function POST(req) {
    try {
      const cfg = await deps.getConfig();
      bridge.setConfig(cfg);
      const url = new URL(req.url);
      const token = url.searchParams.get("token") ?? req.headers.get("x-webhook-token") ?? "";
      if (token === "" || token !== cfg.webhookToken) {
        console.warn("[evolution-chat] webhook rejeitado: token inv\xE1lido ou ausente");
        return json(200, { ignored: true });
      }
      let payload;
      try {
        payload = await req.json();
      } catch {
        console.warn("[evolution-chat] webhook rejeitado: corpo n\xE3o \xE9 JSON v\xE1lido");
        return json(200, { ignored: true });
      }
      const { handled } = await bridge.handleWebhook(payload);
      return json(200, { handled });
    } catch (error) {
      console.error("[evolution-chat] webhook falhou (respondendo 200):", error);
      return json(200, { ignored: true });
    }
  }
  return { POST };
}
export {
  createChatRoutes,
  createWebhookRoute
};
//# sourceMappingURL=index.js.map