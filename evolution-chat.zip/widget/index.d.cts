import { ReactElement } from 'react';

type ChatMessageDirection = "visitor" | "owner" | "system";
type ChatMessageStatus = "pending" | "sent" | "failed";
type ChatSessionStatus = "active" | "closed" | "failed";
/** Mensagem persistida (domínio). */
interface ChatMessage {
    id: string;
    sessionId: string;
    direction: ChatMessageDirection;
    body: string;
    status: ChatMessageStatus;
    waMessageId: string | null;
    createdAt: string;
}
/** Evento de tempo real publicado no canal broadcast `chat:<realtimeToken>`. */
type ChatEvent = {
    type: "message";
    message: ChatMessage;
} | {
    type: "session";
    status: ChatSessionStatus;
}
/** Indicador de digitação: `from` diz quem está digitando (dona da plataforma
 *  ou visitante) para o widget exibir os "3 pontinhos" apenas quando a OUTRA
 *  ponta digita. */
 | {
    type: "typing";
    isTyping: boolean;
    from: "owner" | "visitor";
};

/**
 * Assinatura client-side do mesmo canal (usada pelo widget — Task 9).
 * `subscribe` devolve o unsubscribe; `onStatus` reporta conexão do transporte.
 */
interface RealtimeHandle {
    subscribe(realtimeToken: string, onEvent: (e: ChatEvent) => void, onStatus?: (s: "open" | "closed") => void): () => void;
}

type WidgetLocale = "pt" | "en" | "es";
declare const WIDGET_KEYS: readonly ["openChat", "close", "name", "phone", "message", "send", "sending", "welcomeNotice", "privacyNote", "invalidPhone", "sendError", "retry", "sessionClosed", "newConversation", "poweredBy", "typing"];
type WidgetKey = (typeof WIDGET_KEYS)[number];
/** Dicionário completo: `Record<WidgetKey, string>` força todas as chaves no compilador. */
type WidgetDictionary = Record<WidgetKey, string>;
declare const pt: WidgetDictionary;
declare const en: WidgetDictionary;
declare const es: WidgetDictionary;
declare const dictionaries: Record<WidgetLocale, WidgetDictionary>;
/**
 * Traduz `key` para `locale`, permitindo override pontual de copy (`labels` do widget).
 * Nunca lança: chave desconhecida devolve o texto de pt e, na ausência, a própria chave.
 */
declare function t(locale: WidgetLocale, key: WidgetKey, overrides?: Partial<Record<string, string>>): string;

interface ChatWidgetProps {
    /** Caminho da rota de chat (GET histórico / POST start+send), ex.: "/api/chat". */
    endpoint: string;
    locale: WidgetLocale;
    /** Saudação exibida no pré-chat form. */
    welcome: string;
    projectName: string;
    /** Cor de tema; default "#25D366". */
    accentColor?: string;
    /** Porta do widget (DI — Strategy): subscribe/unsubscribe do canal da sessão. */
    realtime: RealtimeHandle;
    /** Override pontual de copy por chave i18n. */
    labels?: Partial<Record<string, string>>;
}
declare function ChatWidget(props: ChatWidgetProps): ReactElement;

declare const WIDGET_CSS = "/*\n * src/widget/styles.css \u2014 folha de estilos do ChatWidget (classes `.ecw-*`).\n *\n * Fonte can\u00F4nica do CSS INJETADO em runtime: src/widget/styles.ts espelha este arquivo\n * e injeta `<style id=\"ecw-styles\">` via `injectWidgetStyles()` (o widget \u00E9\n * auto-contido \u2014 o consumidor n\u00E3o precisa importar CSS). O teste de paridade em\n * test/widget/widget.test.tsx garante que os dois textos n\u00E3o divergem.\n * Consumidores que preferem `<link>` podem importar \"@erlancarreira/evolution-chat/widget/styles.css\".\n *\n * Acessibilidade: `color-scheme` (dark nativo), `:focus-visible` sempre vis\u00EDvel,\n * contraste AA sobre o accent (texto escuro no verde), e transi\u00E7\u00F5es desligadas com\n * `prefers-reduced-motion`.\n */\n\n.ecw-root {\n  --ecw-accent: #25d366;\n  --ecw-accent-ink: #06251a;\n  --ecw-surface: #ffffff;\n  --ecw-surface-2: #f1f4f7;\n  --ecw-text: #14181d;\n  --ecw-muted: #51606e;\n  --ecw-border: #d7dde3;\n  --ecw-danger: #b3261e;\n  --ecw-shadow: 0 8px 28px rgb(9 20 28 / 22%);\n  color-scheme: light dark;\n  font-family: system-ui, -apple-system, \"Segoe UI\", Roboto, sans-serif;\n  font-size: 14px;\n  line-height: 1.45;\n  color: var(--ecw-text);\n}\n\n@media (prefers-color-scheme: dark) {\n  .ecw-root {\n    --ecw-accent-ink: #04170f;\n    --ecw-surface: #151a20;\n    --ecw-surface-2: #232a33;\n    --ecw-text: #e8edf2;\n    --ecw-muted: #9aa7b4;\n    --ecw-border: #2c343d;\n    --ecw-danger: #ff9a8f;\n    --ecw-shadow: 0 8px 28px rgb(0 0 0 / 45%);\n  }\n}\n\n/* \u2500\u2500 bal\u00E3o flutuante \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */\n.ecw-button {\n  position: fixed;\n  right: 20px;\n  bottom: 20px;\n  z-index: 2147483000;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  width: 56px;\n  height: 56px;\n  padding: 0;\n  border: none;\n  border-radius: 50%;\n  background: var(--ecw-accent);\n  color: var(--ecw-accent-ink);\n  box-shadow: var(--ecw-shadow);\n  cursor: pointer;\n  transition: transform 160ms ease, box-shadow 160ms ease;\n}\n.ecw-button:hover { transform: translateY(-2px) scale(1.03); }\n.ecw-button:active { transform: translateY(0) scale(0.98); }\n.ecw-button svg { width: 26px; height: 26px; }\n\n.ecw-badge {\n  position: absolute;\n  top: -4px;\n  right: -4px;\n  min-width: 22px;\n  height: 22px;\n  padding: 0 6px;\n  border-radius: 11px;\n  border: 2px solid var(--ecw-surface);\n  background: var(--ecw-danger);\n  color: #fff;\n  font-size: 12px;\n  font-weight: 700;\n  line-height: 18px;\n  text-align: center;\n}\n\n/* \u2500\u2500 painel \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */\n.ecw-panel {\n  position: fixed;\n  right: 20px;\n  bottom: 88px;\n  z-index: 2147483000;\n  display: flex;\n  flex-direction: column;\n  width: min(380px, calc(100vw - 24px));\n  min-width: 320px;\n  height: 480px;\n  max-height: 70vh;\n  overflow: hidden;\n  border: 1px solid var(--ecw-border);\n  border-radius: 14px;\n  background: var(--ecw-surface);\n  box-shadow: var(--ecw-shadow);\n  animation: ecw-pop 160ms ease-out;\n}\n@keyframes ecw-pop { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: none; } }\n\n.ecw-header {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  padding: 12px 14px;\n  background: var(--ecw-accent);\n  color: var(--ecw-accent-ink);\n}\n.ecw-title { flex: 1; font-weight: 700; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }\n.ecw-code { font-size: 12px; font-weight: 600; opacity: 0.85; letter-spacing: 0.02em; }\n.ecw-close {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  width: 28px;\n  height: 28px;\n  padding: 0;\n  border: none;\n  border-radius: 8px;\n  background: transparent;\n  color: inherit;\n  font-size: 18px;\n  line-height: 1;\n  cursor: pointer;\n}\n.ecw-close:hover { background: rgb(0 0 0 / 12%); }\n\n/* \u2500\u2500 lista de mensagens \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */\n.ecw-list {\n  flex: 1;\n  margin: 0;\n  padding: 12px;\n  overflow-y: auto;\n  display: flex;\n  flex-direction: column;\n  gap: 10px;\n  list-style: none;\n  background: var(--ecw-surface-2);\n}\n.ecw-item { display: flex; flex-direction: column; max-width: 82%; }\n.ecw-item--visitor { align-self: flex-end; align-items: flex-end; }\n.ecw-item--owner { align-self: flex-start; align-items: flex-start; }\n.ecw-item--system { align-self: center; align-items: center; max-width: 92%; }\n.ecw-system {\n  padding: 4px 10px;\n  border-radius: 999px;\n  background: var(--ecw-surface);\n  border: 1px solid var(--ecw-border);\n  color: var(--ecw-muted);\n  font-size: 11px;\n  text-align: center;\n  overflow-wrap: anywhere;\n}\n.ecw-bubble {\n  padding: 8px 12px;\n  border-radius: 12px;\n  overflow-wrap: anywhere;\n  white-space: pre-wrap;\n}\n.ecw-bubble--visitor {\n  background: var(--ecw-accent);\n  color: var(--ecw-accent-ink);\n  border-bottom-right-radius: 4px;\n}\n.ecw-bubble--owner {\n  background: var(--ecw-surface);\n  color: var(--ecw-text);\n  border: 1px solid var(--ecw-border);\n  border-bottom-left-radius: 4px;\n}\n.ecw-meta { display: flex; align-items: center; gap: 6px; margin-top: 2px; font-size: 11px; color: var(--ecw-muted); }\n.ecw-status--failed { color: var(--ecw-danger); }\n.ecw-retry {\n  padding: 0;\n  border: none;\n  background: none;\n  color: var(--ecw-danger);\n  font: inherit;\n  font-size: 11px;\n  text-decoration: underline;\n  cursor: pointer;\n}\n\n/* \u2500\u2500 pr\u00E9-chat form \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */\n.ecw-form { display: flex; flex-direction: column; gap: 12px; padding: 16px 14px; overflow-y: auto; }\n.ecw-welcome { margin: 0; font-weight: 600; }\n.ecw-notice { margin: 0; font-size: 12px; color: var(--ecw-muted); }\n.ecw-field { display: flex; flex-direction: column; gap: 4px; }\n.ecw-label { font-size: 12px; font-weight: 600; color: var(--ecw-text); }\n.ecw-input {\n  width: 100%;\n  padding: 9px 10px;\n  border: 1px solid var(--ecw-border);\n  border-radius: 8px;\n  background: var(--ecw-surface);\n  color: var(--ecw-text);\n  font: inherit;\n}\n.ecw-input:focus { outline: 2px solid var(--ecw-accent); outline-offset: 1px; }\n.ecw-input[aria-invalid=\"true\"] { border-color: var(--ecw-danger); }\n.ecw-error { margin: 0; font-size: 12px; color: var(--ecw-danger); }\n.ecw-submit {\n  padding: 10px 14px;\n  border: none;\n  border-radius: 8px;\n  background: var(--ecw-accent);\n  color: var(--ecw-accent-ink);\n  font: inherit;\n  font-weight: 700;\n  cursor: pointer;\n}\n.ecw-submit:disabled { opacity: 0.55; cursor: not-allowed; }\n\n/* \u2500\u2500 composer \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */\n.ecw-composer { display: flex; gap: 8px; padding: 10px 12px; border-top: 1px solid var(--ecw-border); background: var(--ecw-surface); }\n.ecw-composer .ecw-input { flex: 1; }\n.ecw-send {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  width: 40px;\n  height: 40px;\n  padding: 0;\n  border: none;\n  border-radius: 8px;\n  background: var(--ecw-accent);\n  color: var(--ecw-accent-ink);\n  cursor: pointer;\n}\n.ecw-send:disabled { opacity: 0.55; cursor: not-allowed; }\n.ecw-send svg { width: 18px; height: 18px; }\n\n/* \u2500\u2500 indicador \"digitando\u2026\" (3 pontinhos) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */\n.ecw-typing {\n  display: inline-flex;\n  align-items: center;\n  gap: 4px;\n  padding: 10px 14px;\n  border-radius: 12px;\n  border-bottom-left-radius: 4px;\n  background: var(--ecw-surface);\n  border: 1px solid var(--ecw-border);\n}\n.ecw-typing-dot {\n  width: 7px;\n  height: 7px;\n  border-radius: 50%;\n  background: var(--ecw-muted);\n  animation: ecw-typing-bounce 1.2s infinite ease-in-out;\n}\n.ecw-typing-dot:nth-child(2) { animation-delay: 0.18s; }\n.ecw-typing-dot:nth-child(3) { animation-delay: 0.36s; }\n@keyframes ecw-typing-bounce {\n  0%, 60%, 100% { transform: translateY(0); opacity: 0.5; }\n  30% { transform: translateY(-4px); opacity: 1; }\n}\n\n/* \u2500\u2500 sess\u00E3o encerrada / falha \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */\n.ecw-closed { display: flex; flex-direction: column; gap: 8px; padding: 10px 12px; border-top: 1px solid var(--ecw-border); background: var(--ecw-surface); }\n\n.ecw-footer { padding: 6px 12px 10px; font-size: 11px; color: var(--ecw-muted); text-align: center; background: var(--ecw-surface); }\n.ecw-powered-link { color: var(--ecw-accent); font-weight: 600; text-decoration: none; }\n.ecw-powered-link:hover { text-decoration: underline; }\n\n/* \u2500\u2500 utilit\u00E1rios \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */\n.ecw-hp { display: none !important; }\n.ecw-sr-only {\n  position: absolute;\n  width: 1px; height: 1px;\n  margin: -1px; padding: 0;\n  overflow: hidden;\n  clip: rect(0 0 0 0);\n  white-space: nowrap;\n  border: 0;\n}\n.ecw-button:focus-visible, .ecw-close:focus-visible, .ecw-submit:focus-visible,\n.ecw-send:focus-visible, .ecw-retry:focus-visible {\n  outline: 3px solid #1b6fec;\n  outline-offset: 2px;\n}\n\n@media (prefers-reduced-motion: reduce) {\n  .ecw-root *, .ecw-root *::before, .ecw-root *::after {\n    animation: none !important;\n    transition: none !important;\n  }\n}\n\n@media (max-width: 420px) {\n  .ecw-panel { right: 12px; left: 12px; width: auto; min-width: 0; bottom: 80px; }\n}\n";
/**
 * Insere a folha do widget no `document.head` (idempotente: uma única tag
 * `<style id="ecw-styles">` por documento, não importa quantas vezes seja chamada).
 * No-op fora de browser (SSR / Node) — o consumidor renderiza com `<link>` do subpath.
 */
declare function injectWidgetStyles(): void;

/** Chave de persistência da sessão no localStorage. */
declare const SESSION_STORAGE_KEY = "ecw:session";
/** Intervalo do fallback de polling quando o canal realtime fecha (ms). */
declare const POLL_INTERVAL_MS = 5000;
/** Mínimo de dígitos (com DDD) para um WhatsApp ser aceito no form. */
declare const MIN_PHONE_DIGITS = 10;
type ChatPhase = "idle" | "form" | "chat";
interface SessionInfo {
    code: string;
    status: ChatSessionStatus;
    visitorName: string;
}
interface ChatState {
    phase: ChatPhase;
    open: boolean;
    session: SessionInfo | null;
    token: string | null;
    messages: ChatMessage[];
    unread: number;
    sending: boolean;
    /** Chave i18n do erro visível ("sendError" | "invalidPhone") ou null. */
    error: string | null;
    /** True enquanto a DONA da plataforma (atendente) digita → "3 pontinhos" no widget. */
    ownerTyping: boolean;
    /** True enquanto o VISITANTE (esta ponta) digita — útil para um painel de atendente. */
    visitorTyping: boolean;
}
/** Só dígitos (o servidor espera DDI+DDD+número sem máscara). */
declare function normalizePhone(value: string): string;
/** Máscara BR parcial `(11) 99999-8888`, progressiva enquanto o usuário digita. */
declare function maskPhone(value: string): string;
declare function isValidPhone(value: string): boolean;
interface UseChatOptions {
    endpoint: string;
    realtime: RealtimeHandle;
    /** Rota que recebe o sinal "visitante digitando" (POST { token, isTyping }). Default: `${endpoint}/typing`. */
    typingEndpoint?: string;
}
interface UseChatResult {
    state: ChatState;
    openPanel(): void;
    closePanel(): void;
    togglePanel(): void;
    submitForm(input: {
        name: string;
        phone: string;
        message: string;
        honeypot: string;
    }): Promise<void>;
    sendMessage(text: string): Promise<void>;
    retryMessage(id: string): Promise<void>;
    /** Descarta a sessão encerrada/falha (storage + estado) e volta ao pré-chat form. */
    startNewConversation(): void;
    /** Avisa o servidor que o visitante está (true) ou parou (false) de digitar. Best-effort. */
    notifyTyping(isTyping: boolean): Promise<void>;
}
declare function useChat({ endpoint, realtime, typingEndpoint }: UseChatOptions): UseChatResult;

export { type ChatPhase, type ChatState, ChatWidget, type ChatWidgetProps, MIN_PHONE_DIGITS, POLL_INTERVAL_MS, type RealtimeHandle, SESSION_STORAGE_KEY, type SessionInfo, type UseChatOptions, type UseChatResult, WIDGET_CSS, WIDGET_KEYS, type WidgetDictionary, type WidgetKey, type WidgetLocale, dictionaries, en, es, injectWidgetStyles, isValidPhone, maskPhone, normalizePhone, pt, t, useChat };
