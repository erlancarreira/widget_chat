"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/widget/index.ts
var widget_exports = {};
__export(widget_exports, {
  ChatWidget: () => ChatWidget,
  MIN_PHONE_DIGITS: () => MIN_PHONE_DIGITS,
  POLL_INTERVAL_MS: () => POLL_INTERVAL_MS,
  SESSION_STORAGE_KEY: () => SESSION_STORAGE_KEY,
  WIDGET_CSS: () => WIDGET_CSS,
  WIDGET_KEYS: () => WIDGET_KEYS,
  dictionaries: () => dictionaries,
  en: () => en,
  es: () => es,
  injectWidgetStyles: () => injectWidgetStyles,
  isValidPhone: () => isValidPhone,
  maskPhone: () => maskPhone,
  normalizePhone: () => normalizePhone,
  pt: () => pt,
  t: () => t,
  useChat: () => useChat
});
module.exports = __toCommonJS(widget_exports);

// src/widget/chat-widget.tsx
var import_react2 = require("react");

// src/widget/i18n.ts
var WIDGET_KEYS = [
  "openChat",
  "close",
  "name",
  "phone",
  "message",
  "send",
  "sending",
  "welcomeNotice",
  "privacyNote",
  "invalidPhone",
  "sendError",
  "retry",
  "sessionClosed",
  "newConversation",
  "poweredBy",
  "typing"
];
var pt = {
  openChat: "Abrir chat",
  close: "Fechar",
  name: "Nome",
  phone: "WhatsApp",
  message: "Mensagem",
  send: "Enviar",
  sending: "Enviando\u2026",
  welcomeNotice: "Ao continuar, voc\xEA entra no grupo de WhatsApp do site com o nosso time.",
  privacyNote: "Seus dados s\xE3o usados apenas para o atendimento.",
  invalidPhone: "Informe um n\xFAmero v\xE1lido com DDD (m\xEDnimo 10 d\xEDgitos).",
  sendError: "N\xE3o foi poss\xEDvel enviar. Tente novamente.",
  retry: "Tentar novamente",
  sessionClosed: "Esta conversa foi encerrada. Abra uma nova para continuar.",
  newConversation: "Iniciar nova conversa",
  poweredBy: "Powered by",
  typing: "digitando\u2026"
};
var en = {
  openChat: "Open chat",
  close: "Close",
  name: "Name",
  phone: "WhatsApp",
  message: "Message",
  send: "Send",
  sending: "Sending\u2026",
  welcomeNotice: "When you continue, you join the site's WhatsApp group with our team.",
  privacyNote: "Your data is used only for support.",
  invalidPhone: "Enter a valid number with area code (at least 10 digits).",
  sendError: "Couldn't send. Please try again.",
  retry: "Try again",
  sessionClosed: "This conversation was closed. Start a new one to continue.",
  newConversation: "Start a new conversation",
  poweredBy: "Powered by",
  typing: "typing\u2026"
};
var es = {
  openChat: "Abrir chat",
  close: "Cerrar",
  name: "Nombre",
  phone: "WhatsApp",
  message: "Mensaje",
  send: "Enviar",
  sending: "Enviando\u2026",
  welcomeNotice: "Al continuar, entras en el grupo de WhatsApp del sitio con nuestro equipo.",
  privacyNote: "Tus datos se usan solo para la atenci\xF3n.",
  invalidPhone: "Introduce un n\xFAmero v\xE1lido con \xE1rea (m\xEDnimo 10 d\xEDgitos).",
  sendError: "No se pudo enviar. Int\xE9ntalo de nuevo.",
  retry: "Reintentar",
  sessionClosed: "Esta conversaci\xF3n fue cerrada. Abre una nueva para continuar.",
  newConversation: "Iniciar nueva conversaci\xF3n",
  poweredBy: "Powered by",
  typing: "escribiendo\u2026"
};
var dictionaries = { pt, en, es };
function t(locale, key, overrides) {
  const override = overrides?.[key];
  if (override !== void 0) return override;
  const dict = dictionaries[locale];
  return dict[key] ?? dictionaries.pt[key] ?? key;
}

// src/widget/styles.ts
var WIDGET_CSS = `/*
 * src/widget/styles.css \u2014 folha de estilos do ChatWidget (classes \`.ecw-*\`).
 *
 * Fonte can\xF4nica do CSS INJETADO em runtime: src/widget/styles.ts espelha este arquivo
 * e injeta \`<style id="ecw-styles">\` via \`injectWidgetStyles()\` (o widget \xE9
 * auto-contido \u2014 o consumidor n\xE3o precisa importar CSS). O teste de paridade em
 * test/widget/widget.test.tsx garante que os dois textos n\xE3o divergem.
 * Consumidores que preferem \`<link>\` podem importar "@erlancarreira/evolution-chat/widget/styles.css".
 *
 * Acessibilidade: \`color-scheme\` (dark nativo), \`:focus-visible\` sempre vis\xEDvel,
 * contraste AA sobre o accent (texto escuro no verde), e transi\xE7\xF5es desligadas com
 * \`prefers-reduced-motion\`.
 */

.ecw-root {
  --ecw-accent: #25d366;
  --ecw-accent-ink: #06251a;
  --ecw-surface: #ffffff;
  --ecw-surface-2: #f1f4f7;
  --ecw-text: #14181d;
  --ecw-muted: #51606e;
  --ecw-border: #d7dde3;
  --ecw-danger: #b3261e;
  --ecw-shadow: 0 8px 28px rgb(9 20 28 / 22%);
  color-scheme: light dark;
  font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
  font-size: 14px;
  line-height: 1.45;
  color: var(--ecw-text);
}

@media (prefers-color-scheme: dark) {
  .ecw-root {
    --ecw-accent-ink: #04170f;
    --ecw-surface: #151a20;
    --ecw-surface-2: #232a33;
    --ecw-text: #e8edf2;
    --ecw-muted: #9aa7b4;
    --ecw-border: #2c343d;
    --ecw-danger: #ff9a8f;
    --ecw-shadow: 0 8px 28px rgb(0 0 0 / 45%);
  }
}

/* \u2500\u2500 bal\xE3o flutuante \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
.ecw-button {
  position: fixed;
  right: 20px;
  bottom: 20px;
  z-index: 2147483000;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 56px;
  height: 56px;
  padding: 0;
  border: none;
  border-radius: 50%;
  background: var(--ecw-accent);
  color: var(--ecw-accent-ink);
  box-shadow: var(--ecw-shadow);
  cursor: pointer;
  transition: transform 160ms ease, box-shadow 160ms ease;
}
.ecw-button:hover { transform: translateY(-2px) scale(1.03); }
.ecw-button:active { transform: translateY(0) scale(0.98); }
.ecw-button svg { width: 26px; height: 26px; }

.ecw-badge {
  position: absolute;
  top: -4px;
  right: -4px;
  min-width: 22px;
  height: 22px;
  padding: 0 6px;
  border-radius: 11px;
  border: 2px solid var(--ecw-surface);
  background: var(--ecw-danger);
  color: #fff;
  font-size: 12px;
  font-weight: 700;
  line-height: 18px;
  text-align: center;
}

/* \u2500\u2500 painel \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
.ecw-panel {
  position: fixed;
  right: 20px;
  bottom: 88px;
  z-index: 2147483000;
  display: flex;
  flex-direction: column;
  width: min(380px, calc(100vw - 24px));
  min-width: 320px;
  height: 480px;
  max-height: 70vh;
  overflow: hidden;
  border: 1px solid var(--ecw-border);
  border-radius: 14px;
  background: var(--ecw-surface);
  box-shadow: var(--ecw-shadow);
  animation: ecw-pop 160ms ease-out;
}
@keyframes ecw-pop { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: none; } }

.ecw-header {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 14px;
  background: var(--ecw-accent);
  color: var(--ecw-accent-ink);
}
.ecw-title { flex: 1; font-weight: 700; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.ecw-code { font-size: 12px; font-weight: 600; opacity: 0.85; letter-spacing: 0.02em; }
.ecw-close {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 28px;
  height: 28px;
  padding: 0;
  border: none;
  border-radius: 8px;
  background: transparent;
  color: inherit;
  font-size: 18px;
  line-height: 1;
  cursor: pointer;
}
.ecw-close:hover { background: rgb(0 0 0 / 12%); }

/* \u2500\u2500 lista de mensagens \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
.ecw-list {
  flex: 1;
  margin: 0;
  padding: 12px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 10px;
  list-style: none;
  background: var(--ecw-surface-2);
}
.ecw-item { display: flex; flex-direction: column; max-width: 82%; }
.ecw-item--visitor { align-self: flex-end; align-items: flex-end; }
.ecw-item--owner { align-self: flex-start; align-items: flex-start; }
.ecw-item--system { align-self: center; align-items: center; max-width: 92%; }
.ecw-system {
  padding: 4px 10px;
  border-radius: 999px;
  background: var(--ecw-surface);
  border: 1px solid var(--ecw-border);
  color: var(--ecw-muted);
  font-size: 11px;
  text-align: center;
  overflow-wrap: anywhere;
}
.ecw-bubble {
  padding: 8px 12px;
  border-radius: 12px;
  overflow-wrap: anywhere;
  white-space: pre-wrap;
}
.ecw-bubble--visitor {
  background: var(--ecw-accent);
  color: var(--ecw-accent-ink);
  border-bottom-right-radius: 4px;
}
.ecw-bubble--owner {
  background: var(--ecw-surface);
  color: var(--ecw-text);
  border: 1px solid var(--ecw-border);
  border-bottom-left-radius: 4px;
}
.ecw-meta { display: flex; align-items: center; gap: 6px; margin-top: 2px; font-size: 11px; color: var(--ecw-muted); }
.ecw-status--failed { color: var(--ecw-danger); }
.ecw-retry {
  padding: 0;
  border: none;
  background: none;
  color: var(--ecw-danger);
  font: inherit;
  font-size: 11px;
  text-decoration: underline;
  cursor: pointer;
}

/* \u2500\u2500 pr\xE9-chat form \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
.ecw-form { display: flex; flex-direction: column; gap: 12px; padding: 16px 14px; overflow-y: auto; }
.ecw-welcome { margin: 0; font-weight: 600; }
.ecw-notice { margin: 0; font-size: 12px; color: var(--ecw-muted); }
.ecw-field { display: flex; flex-direction: column; gap: 4px; }
.ecw-label { font-size: 12px; font-weight: 600; color: var(--ecw-text); }
.ecw-input {
  width: 100%;
  padding: 9px 10px;
  border: 1px solid var(--ecw-border);
  border-radius: 8px;
  background: var(--ecw-surface);
  color: var(--ecw-text);
  font: inherit;
}
.ecw-input:focus { outline: 2px solid var(--ecw-accent); outline-offset: 1px; }
.ecw-input[aria-invalid="true"] { border-color: var(--ecw-danger); }
.ecw-error { margin: 0; font-size: 12px; color: var(--ecw-danger); }
.ecw-submit {
  padding: 10px 14px;
  border: none;
  border-radius: 8px;
  background: var(--ecw-accent);
  color: var(--ecw-accent-ink);
  font: inherit;
  font-weight: 700;
  cursor: pointer;
}
.ecw-submit:disabled { opacity: 0.55; cursor: not-allowed; }

/* \u2500\u2500 composer \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
.ecw-composer { display: flex; gap: 8px; padding: 10px 12px; border-top: 1px solid var(--ecw-border); background: var(--ecw-surface); }
.ecw-composer .ecw-input { flex: 1; }
.ecw-send {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 40px;
  height: 40px;
  padding: 0;
  border: none;
  border-radius: 8px;
  background: var(--ecw-accent);
  color: var(--ecw-accent-ink);
  cursor: pointer;
}
.ecw-send:disabled { opacity: 0.55; cursor: not-allowed; }
.ecw-send svg { width: 18px; height: 18px; }

/* \u2500\u2500 indicador "digitando\u2026" (3 pontinhos) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
.ecw-typing {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 10px 14px;
  border-radius: 12px;
  border-bottom-left-radius: 4px;
  background: var(--ecw-surface);
  border: 1px solid var(--ecw-border);
}
.ecw-typing-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: var(--ecw-muted);
  animation: ecw-typing-bounce 1.2s infinite ease-in-out;
}
.ecw-typing-dot:nth-child(2) { animation-delay: 0.18s; }
.ecw-typing-dot:nth-child(3) { animation-delay: 0.36s; }
@keyframes ecw-typing-bounce {
  0%, 60%, 100% { transform: translateY(0); opacity: 0.5; }
  30% { transform: translateY(-4px); opacity: 1; }
}

/* \u2500\u2500 sess\xE3o encerrada / falha \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
.ecw-closed { display: flex; flex-direction: column; gap: 8px; padding: 10px 12px; border-top: 1px solid var(--ecw-border); background: var(--ecw-surface); }

.ecw-footer { padding: 6px 12px 10px; font-size: 11px; color: var(--ecw-muted); text-align: center; background: var(--ecw-surface); }
.ecw-powered-link { color: var(--ecw-accent); font-weight: 600; text-decoration: none; }
.ecw-powered-link:hover { text-decoration: underline; }

/* \u2500\u2500 utilit\xE1rios \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
.ecw-hp { display: none !important; }
.ecw-sr-only {
  position: absolute;
  width: 1px; height: 1px;
  margin: -1px; padding: 0;
  overflow: hidden;
  clip: rect(0 0 0 0);
  white-space: nowrap;
  border: 0;
}
.ecw-button:focus-visible, .ecw-close:focus-visible, .ecw-submit:focus-visible,
.ecw-send:focus-visible, .ecw-retry:focus-visible {
  outline: 3px solid #1b6fec;
  outline-offset: 2px;
}

@media (prefers-reduced-motion: reduce) {
  .ecw-root *, .ecw-root *::before, .ecw-root *::after {
    animation: none !important;
    transition: none !important;
  }
}

@media (max-width: 420px) {
  .ecw-panel { right: 12px; left: 12px; width: auto; min-width: 0; bottom: 80px; }
}
`;
var injected = false;
function injectWidgetStyles() {
  if (typeof document === "undefined") return;
  if (injected && document.getElementById("ecw-styles") !== null) return;
  const existing = document.getElementById("ecw-styles");
  if (existing !== null) {
    injected = true;
    return;
  }
  const style = document.createElement("style");
  style.id = "ecw-styles";
  style.textContent = WIDGET_CSS;
  document.head.appendChild(style);
  injected = true;
}

// src/widget/use-chat.ts
var import_react = require("react");
var SESSION_STORAGE_KEY = "ecw:session";
var POLL_INTERVAL_MS = 5e3;
var MIN_PHONE_DIGITS = 10;
var initialState = {
  phase: "idle",
  open: false,
  session: null,
  token: null,
  messages: [],
  unread: 0,
  sending: false,
  error: null,
  ownerTyping: false,
  visitorTyping: false
};
function withMessage(state, message) {
  const index = state.messages.findIndex((m) => m.id === message.id);
  let messages;
  if (index >= 0) {
    messages = [...state.messages];
    messages[index] = message;
  } else {
    messages = [...state.messages, message];
  }
  const bump = state.open || message.direction !== "owner" ? 0 : 1;
  const next = { ...state, messages, unread: state.unread + bump };
  if (message.direction === "owner") next.ownerTyping = false;
  return next;
}
function chatReducer(state, action) {
  switch (action.type) {
    case "open":
      return {
        ...state,
        open: true,
        unread: 0,
        phase: state.phase === "idle" ? "form" : state.phase
      };
    case "close":
      return { ...state, open: false };
    case "restore":
      return {
        ...state,
        phase: "chat",
        session: action.session,
        token: action.token,
        messages: action.messages
      };
    case "start": {
      let next = {
        ...state,
        phase: "chat",
        session: action.session,
        token: action.token,
        messages: action.messages
      };
      for (const pending of state.messages) {
        const confirmed = action.messages.some(
          (m) => m.direction === "visitor" && m.body === pending.body
        );
        if (pending.status === "pending" && !confirmed) next = withMessage(next, pending);
      }
      return next;
    }
    case "reset-form":
      return { ...state, phase: "form", session: null, token: null, messages: [], unread: 0, error: null };
    case "append":
      return withMessage(state, action.message);
    case "merge": {
      let next = state;
      for (const message of action.messages) next = withMessage(next, message);
      return next;
    }
    case "replace": {
      const messages = state.messages.map((m) => m.id === action.tmpId ? action.message : m);
      const kept = messages.some((m) => m.id === action.message.id);
      return { ...state, messages: kept ? messages : [...messages, action.message] };
    }
    case "mark":
      return {
        ...state,
        messages: state.messages.map((m) => m.id === action.id ? { ...m, status: action.status } : m)
      };
    case "session-status": {
      if (state.session === null) return state;
      return { ...state, session: { ...state.session, status: action.status } };
    }
    case "sending":
      return { ...state, sending: action.value };
    case "error":
      return { ...state, error: action.value };
    case "typing":
      return action.from === "owner" ? state.ownerTyping === action.isTyping ? state : { ...state, ownerTyping: action.isTyping } : state.visitorTyping === action.isTyping ? state : { ...state, visitorTyping: action.isTyping };
  }
}
function normalizePhone(value) {
  return value.replace(/\D/g, "");
}
function maskPhone(value) {
  const digits = normalizePhone(value).slice(0, 11);
  if (digits.length === 0) return "";
  const ddd = digits.slice(0, 2);
  if (digits.length <= 2) return `(${ddd}`;
  const rest = digits.slice(2);
  if (rest.length <= 5) return `(${ddd}) ${rest}`;
  return `(${ddd}) ${rest.slice(0, 5)}-${rest.slice(5)}`;
}
function isValidPhone(value) {
  return normalizePhone(value).length >= MIN_PHONE_DIGITS;
}
function readStoredSession() {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(SESSION_STORAGE_KEY);
    if (raw === null) return null;
    const parsed = JSON.parse(raw);
    if (parsed !== null && typeof parsed === "object" && typeof parsed.token === "string" && parsed.token !== "") {
      const { token, code } = parsed;
      return { token, code: typeof code === "string" ? code : "" };
    }
    return null;
  } catch {
    return null;
  }
}
function writeStoredSession(session) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session));
  } catch {
  }
}
function clearStoredSession() {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.removeItem(SESSION_STORAGE_KEY);
  } catch {
  }
}
function historyUrl(endpoint, token, after) {
  const params = new URLSearchParams({ token });
  if (after !== null) params.set("after", after);
  const sep = endpoint.includes("?") ? "&" : "?";
  return `${endpoint}${sep}${params.toString()}`;
}
function lastCursor(messages) {
  let latest = null;
  for (const m of messages) if (latest === null || m.createdAt > latest) latest = m.createdAt;
  return latest;
}
var tmpSeq = 0;
function tmpMessage(body) {
  tmpSeq += 1;
  return {
    id: `tmp-${tmpSeq}`,
    sessionId: "",
    direction: "visitor",
    body,
    status: "pending",
    waMessageId: null,
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  };
}
function useChat({ endpoint, realtime, typingEndpoint }) {
  const [state, dispatch] = (0, import_react.useReducer)(chatReducer, initialState);
  const typingUrl = typingEndpoint ?? `${endpoint.replace(/\/+$/, "")}/typing`;
  const stateRef = (0, import_react.useRef)(state);
  (0, import_react.useEffect)(() => {
    stateRef.current = state;
  }, [state]);
  const realtimeRef = (0, import_react.useRef)(realtime);
  (0, import_react.useEffect)(() => {
    realtimeRef.current = realtime;
  }, [realtime]);
  const pollRef = (0, import_react.useRef)(null);
  const stopPoll = (0, import_react.useCallback)(() => {
    if (pollRef.current !== null) {
      clearInterval(pollRef.current);
      pollRef.current = null;
    }
  }, []);
  const pollOnce = (0, import_react.useCallback)(async () => {
    const { token, messages } = stateRef.current;
    if (token === null) return;
    try {
      const res = await fetch(historyUrl(endpoint, token, lastCursor(messages)), {
        method: "GET",
        headers: { accept: "application/json" }
      });
      if (res.status === 404) {
        clearStoredSession();
        stopPoll();
        dispatch({ type: "reset-form" });
        return;
      }
      if (!res.ok) return;
      const data = await res.json();
      if (Array.isArray(data.messages)) dispatch({ type: "merge", messages: data.messages });
      if (data.session !== void 0) dispatch({ type: "session-status", status: data.session.status });
    } catch {
    }
  }, [endpoint, stopPoll]);
  const startPoll = (0, import_react.useCallback)(() => {
    if (pollRef.current !== null) return;
    pollRef.current = setInterval(() => {
      void pollOnce();
    }, POLL_INTERVAL_MS);
  }, [pollOnce]);
  const handleStatus = (0, import_react.useCallback)(
    (s) => {
      if (s === "closed") startPoll();
      else stopPoll();
    },
    [startPoll, stopPoll]
  );
  const handleEvent = (0, import_react.useCallback)((e) => {
    if (e.type === "message" && e.message !== void 0) {
      dispatch({ type: "append", message: e.message });
    } else if (e.type === "session" && e.status !== void 0) {
      dispatch({ type: "session-status", status: e.status });
    } else if (e.type === "typing" && e.from !== void 0) {
      dispatch({ type: "typing", from: e.from, isTyping: e.isTyping });
    }
  }, []);
  (0, import_react.useEffect)(() => {
    const stored = readStoredSession();
    if (stored === null) return;
    let cancelled = false;
    void (async () => {
      try {
        const res = await fetch(historyUrl(endpoint, stored.token, null), {
          method: "GET",
          headers: { accept: "application/json" }
        });
        if (cancelled) return;
        if (res.status === 404) {
          clearStoredSession();
          dispatch({ type: "reset-form" });
          return;
        }
        if (!res.ok) return;
        const data = await res.json();
        if (cancelled || data.session === void 0) return;
        dispatch({
          type: "restore",
          session: data.session,
          token: stored.token,
          messages: Array.isArray(data.messages) ? data.messages : []
        });
      } catch {
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [endpoint]);
  (0, import_react.useEffect)(() => {
    const token = state.token;
    if (token === null) return;
    const unsubscribe = realtimeRef.current.subscribe(token, handleEvent, handleStatus);
    return () => {
      unsubscribe();
      stopPoll();
    };
  }, [state.token, handleEvent, handleStatus, stopPoll]);
  (0, import_react.useEffect)(() => stopPoll, [stopPoll]);
  const openPanel = (0, import_react.useCallback)(() => {
    dispatch({ type: "open" });
  }, []);
  const closePanel = (0, import_react.useCallback)(() => {
    dispatch({ type: "close" });
  }, []);
  const togglePanel = (0, import_react.useCallback)(() => {
    if (stateRef.current.open) dispatch({ type: "close" });
    else dispatch({ type: "open" });
  }, []);
  const postMessage = (0, import_react.useCallback)(
    async (token, body, id) => {
      dispatch({ type: "sending", value: true });
      dispatch({ type: "error", value: null });
      try {
        const res = await fetch(endpoint, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ token, message: body })
        });
        if (!res.ok) {
          dispatch({ type: "mark", id, status: "failed" });
          dispatch({ type: "error", value: "sendError" });
          return;
        }
        const data = await res.json();
        if (data.message !== void 0) dispatch({ type: "replace", tmpId: id, message: data.message });
        else dispatch({ type: "mark", id, status: "failed" });
      } catch {
        dispatch({ type: "mark", id, status: "failed" });
        dispatch({ type: "error", value: "sendError" });
      } finally {
        dispatch({ type: "sending", value: false });
      }
    },
    [endpoint]
  );
  const sendMessage = (0, import_react.useCallback)(
    async (text) => {
      const body = text.trim();
      const token = stateRef.current.token;
      if (body === "" || token === null) return;
      const optimistic = tmpMessage(body);
      dispatch({ type: "append", message: optimistic });
      await postMessage(token, body, optimistic.id);
    },
    [postMessage]
  );
  const retryMessage = (0, import_react.useCallback)(
    async (id) => {
      const token = stateRef.current.token;
      const target = stateRef.current.messages.find((m) => m.id === id);
      if (token === null || target === void 0 || target.direction !== "visitor") return;
      dispatch({ type: "mark", id, status: "pending" });
      await postMessage(token, target.body, id);
    },
    [postMessage]
  );
  const startNewConversation = (0, import_react.useCallback)(() => {
    clearStoredSession();
    dispatch({ type: "reset-form" });
  }, []);
  const notifyTyping = (0, import_react.useCallback)(
    async (isTyping) => {
      const token = stateRef.current.token;
      if (token === null) return;
      try {
        await fetch(typingUrl, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ token, isTyping })
        });
      } catch {
      }
    },
    [typingUrl]
  );
  const submitForm = (0, import_react.useCallback)(
    async ({ name, phone, message, honeypot }) => {
      if (honeypot.trim() !== "") return;
      const digits = normalizePhone(phone);
      if (name.trim() === "" || message.trim() === "" || digits.length < MIN_PHONE_DIGITS) {
        dispatch({ type: "error", value: digits.length < MIN_PHONE_DIGITS ? "invalidPhone" : "sendError" });
        return;
      }
      const optimistic = tmpMessage(message.trim());
      dispatch({ type: "append", message: optimistic });
      dispatch({ type: "sending", value: true });
      dispatch({ type: "error", value: null });
      try {
        const res = await fetch(endpoint, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ name: name.trim(), phone: digits, message: message.trim(), honeypot: "" })
        });
        if (!res.ok) {
          dispatch({ type: "mark", id: optimistic.id, status: "failed" });
          dispatch({ type: "error", value: "sendError" });
          return;
        }
        const data = await res.json();
        const session = data.session;
        if (session === void 0 || typeof session.realtimeToken !== "string" || session.realtimeToken === "") {
          dispatch({ type: "mark", id: optimistic.id, status: "failed" });
          dispatch({ type: "error", value: "sendError" });
          return;
        }
        const token = session.realtimeToken;
        writeStoredSession({ token, code: session.code });
        dispatch({
          type: "start",
          session: { code: session.code, status: session.status, visitorName: session.visitorName },
          token,
          messages: Array.isArray(data.messages) ? data.messages : []
        });
      } catch {
        dispatch({ type: "mark", id: optimistic.id, status: "failed" });
        dispatch({ type: "error", value: "sendError" });
      } finally {
        dispatch({ type: "sending", value: false });
      }
    },
    [endpoint]
  );
  return { state, openPanel, closePanel, togglePanel, submitForm, sendMessage, retryMessage, startNewConversation, notifyTyping };
}

// src/widget/chat-widget.tsx
var import_jsx_runtime = require("react/jsx-runtime");
var DEFAULT_ACCENT = "#25D366";
function ChatIcon() {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", "aria-hidden": "true", focusable: "false", children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M21 11.5a8.38 8.38 0 0 1-8.5 8.5c-1.5 0-2.9-.36-4.13-1L3 20l1.1-3.85A8.36 8.36 0 0 1 12.5 3 8.38 8.38 0 0 1 21 11.5z" }) });
}
function SendIcon() {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", "aria-hidden": "true", focusable: "false", children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M22 2 11 13" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M22 2 15 22l-4-9-9-4 20-7z" })
  ] });
}
function formatTime(iso, locale) {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "";
  return new Intl.DateTimeFormat(locale, { hour: "2-digit", minute: "2-digit" }).format(date);
}
function StatusMark({ status }) {
  const glyph = status === "pending" ? "\u2713" : status === "sent" ? "\u2713\u2713" : "\u26A0";
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: status === "failed" ? "ecw-status ecw-status--failed" : "ecw-status", "aria-hidden": "true", children: glyph });
}
function TypingIndicator({ label }) {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { className: "ecw-item ecw-item--owner", "aria-live": "polite", children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ecw-typing", role: "status", "aria-label": label, children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ecw-typing-dot" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ecw-typing-dot" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ecw-typing-dot" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ecw-sr-only", children: label })
  ] }) });
}
function PreChatForm({ welcome, tr, error, sending, firstFieldRef, onSubmit }) {
  const uid = (0, import_react2.useId)();
  const [name, setName] = (0, import_react2.useState)("");
  const [phone, setPhone] = (0, import_react2.useState)("");
  const [message, setMessage] = (0, import_react2.useState)("");
  const [honeypot, setHoneypot] = (0, import_react2.useState)("");
  const [phoneTouched, setPhoneTouched] = (0, import_react2.useState)(false);
  const phoneValid = isValidPhone(phone);
  const complete = name.trim() !== "" && phoneValid && message.trim() !== "";
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!complete || sending) return;
    void onSubmit({ name, phone, message, honeypot });
  };
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", { className: "ecw-form", onSubmit: handleSubmit, noValidate: true, children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "ecw-welcome", children: welcome }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "ecw-notice", children: tr("welcomeNotice") }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ecw-field", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { className: "ecw-label", htmlFor: `${uid}-name`, children: tr("name") }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "input",
        {
          id: `${uid}-name`,
          ref: firstFieldRef,
          className: "ecw-input",
          type: "text",
          autoComplete: "name",
          value: name,
          onChange: (e) => {
            setName(e.target.value);
          },
          required: true
        }
      )
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ecw-field", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { className: "ecw-label", htmlFor: `${uid}-phone`, children: tr("phone") }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "input",
        {
          id: `${uid}-phone`,
          className: "ecw-input",
          type: "tel",
          inputMode: "tel",
          autoComplete: "tel",
          placeholder: "(11) 99999-8888",
          value: phone,
          onChange: (e) => {
            setPhone(maskPhone(e.target.value));
          },
          onBlur: () => {
            setPhoneTouched(true);
          },
          "aria-invalid": phoneTouched && !phoneValid ? true : void 0,
          "aria-describedby": phoneTouched && !phoneValid ? `${uid}-phone-err` : void 0,
          required: true
        }
      ),
      phoneTouched && !phoneValid && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "ecw-error", id: `${uid}-phone-err`, role: "alert", children: tr("invalidPhone") })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ecw-field", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { className: "ecw-label", htmlFor: `${uid}-message`, children: tr("message") }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "textarea",
        {
          id: `${uid}-message`,
          className: "ecw-input",
          rows: 3,
          autoComplete: "off",
          value: message,
          onChange: (e) => {
            setMessage(e.target.value);
          },
          required: true
        }
      )
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ecw-hp", "aria-hidden": "true", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { htmlFor: `${uid}-website`, children: "Website" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "input",
        {
          id: `${uid}-website`,
          name: "website",
          type: "text",
          tabIndex: -1,
          autoComplete: "off",
          value: honeypot,
          onChange: (e) => {
            setHoneypot(e.target.value);
          }
        }
      )
    ] }),
    error === "sendError" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "ecw-error", role: "alert", children: tr("sendError") }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: "ecw-submit", type: "submit", disabled: !complete || sending, children: sending ? tr("sending") : tr("send") }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "ecw-notice", children: tr("privacyNote") })
  ] });
}
function ChatPanel({ messages, canCompose, sending, locale, tr, listRef, firstFieldRef, ownerTyping, onTyping, onSend, onRetry, onNewConversation }) {
  const uid = (0, import_react2.useId)();
  const [draft, setDraft] = (0, import_react2.useState)("");
  const typingTimer = (0, import_react2.useRef)(null);
  (0, import_react2.useEffect)(() => {
    return () => {
      if (typingTimer.current !== null) clearTimeout(typingTimer.current);
    };
  }, []);
  const handleDraftChange = (e) => {
    setDraft(e.target.value);
    if (!canCompose) return;
    void onTyping(true);
    if (typingTimer.current !== null) clearTimeout(typingTimer.current);
    typingTimer.current = setTimeout(() => {
      void onTyping(false);
      typingTimer.current = null;
    }, 2500);
  };
  const submit = (e) => {
    e.preventDefault();
    const text = draft.trim();
    if (text === "" || !canCompose) return;
    if (typingTimer.current !== null) {
      clearTimeout(typingTimer.current);
      typingTimer.current = null;
    }
    void onTyping(false);
    setDraft("");
    void onSend(text);
  };
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", { ref: listRef, className: "ecw-list", children: [
      messages.map(
        (m) => m.direction === "system" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { className: "ecw-item ecw-item--system", role: "status", children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ecw-system", children: m.body }) }, m.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { className: `ecw-item ecw-item--${m.direction}`, children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `ecw-bubble ecw-bubble--${m.direction}`, children: m.body }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ecw-meta", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("time", { dateTime: m.createdAt, children: formatTime(m.createdAt, locale) }),
            m.direction === "visitor" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusMark, { status: m.status }),
            m.status === "failed" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "button", className: "ecw-retry", onClick: () => {
              void onRetry(m.id);
            }, children: tr("retry") })
          ] })
        ] }, m.id)
      ),
      ownerTyping && canCompose && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TypingIndicator, { label: tr("typing") })
    ] }),
    !canCompose && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ecw-closed", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "ecw-notice", role: "status", children: tr("sessionClosed") }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "button", className: "ecw-submit", onClick: onNewConversation, children: tr("newConversation") })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", { className: "ecw-composer", onSubmit: submit, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { className: "ecw-sr-only", htmlFor: `${uid}-input`, children: tr("message") }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "input",
        {
          id: `${uid}-input`,
          ref: firstFieldRef,
          className: "ecw-input",
          type: "text",
          autoComplete: "off",
          placeholder: tr("message"),
          value: draft,
          onChange: handleDraftChange,
          disabled: !canCompose
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { className: "ecw-send", type: "submit", disabled: !canCompose || draft.trim() === "" || sending, "aria-label": sending ? tr("sending") : tr("send"), children: sending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ecw-sr-only", children: tr("sending") }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SendIcon, {}) })
    ] })
  ] });
}
function ChatWidget(props) {
  const { endpoint, locale, welcome, projectName, realtime, labels } = props;
  const accentColor = props.accentColor ?? DEFAULT_ACCENT;
  const tr = (0, import_react2.useCallback)((key) => t(locale, key, labels), [locale, labels]);
  const { state, closePanel, togglePanel, submitForm, sendMessage, retryMessage, startNewConversation, notifyTyping } = useChat({ endpoint, realtime });
  const bubbleRef = (0, import_react2.useRef)(null);
  const listRef = (0, import_react2.useRef)(null);
  const firstFieldRef = (0, import_react2.useRef)(null);
  (0, import_react2.useEffect)(() => {
    injectWidgetStyles();
  }, []);
  (0, import_react2.useEffect)(() => {
    if (state.open) firstFieldRef.current?.focus();
  }, [state.open, state.phase]);
  (0, import_react2.useEffect)(() => {
    if (!state.open) return;
    const onKeyDown = (e) => {
      if (e.key !== "Escape") return;
      closePanel();
      bubbleRef.current?.focus();
    };
    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.removeEventListener("keydown", onKeyDown);
    };
  }, [state.open, closePanel]);
  (0, import_react2.useEffect)(() => {
    const list = listRef.current;
    if (list !== null) list.scrollTop = list.scrollHeight;
  }, [state.messages, state.ownerTyping, state.open]);
  const handleClose = (0, import_react2.useCallback)(() => {
    closePanel();
    bubbleRef.current?.focus();
  }, [closePanel]);
  const canCompose = state.session?.status === "active";
  const bubbleLabel = state.unread > 0 ? `${tr("openChat")} (${state.unread})` : tr("openChat");
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "ecw-root", style: { "--ecw-accent": accentColor }, children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(
      "button",
      {
        ref: bubbleRef,
        type: "button",
        className: "ecw-button",
        "aria-label": bubbleLabel,
        "aria-expanded": state.open,
        "aria-haspopup": "dialog",
        onClick: togglePanel,
        children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatIcon, {}),
          state.unread > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ecw-badge", children: state.unread })
        ]
      }
    ),
    state.open && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { className: "ecw-panel", role: "dialog", "aria-label": "Chat", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { className: "ecw-header", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ecw-title", children: projectName }),
        state.session !== null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { className: "ecw-code", children: [
          "#",
          state.session.code
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "button", className: "ecw-close", "aria-label": tr("close"), onClick: handleClose, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { "aria-hidden": "true", children: "\xD7" }) })
      ] }),
      state.phase === "chat" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        ChatPanel,
        {
          messages: state.messages,
          canCompose,
          sending: state.sending,
          locale,
          tr,
          listRef,
          firstFieldRef,
          ownerTyping: state.ownerTyping,
          onTyping: notifyTyping,
          onSend: sendMessage,
          onRetry: retryMessage,
          onNewConversation: startNewConversation
        }
      ) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        PreChatForm,
        {
          welcome,
          tr,
          error: state.error,
          sending: state.sending,
          firstFieldRef,
          onSubmit: submitForm
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", { className: "ecw-footer", children: [
        tr("poweredBy"),
        " ",
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          "a",
          {
            className: "ecw-powered-link",
            href: "https://erlancarreira.com.br",
            target: "_blank",
            rel: "noopener noreferrer",
            children: "Erlan Carreira"
          }
        )
      ] })
    ] })
  ] });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ChatWidget,
  MIN_PHONE_DIGITS,
  POLL_INTERVAL_MS,
  SESSION_STORAGE_KEY,
  WIDGET_CSS,
  WIDGET_KEYS,
  dictionaries,
  en,
  es,
  injectWidgetStyles,
  isValidPhone,
  maskPhone,
  normalizePhone,
  pt,
  t,
  useChat
});
//# sourceMappingURL=index.cjs.map