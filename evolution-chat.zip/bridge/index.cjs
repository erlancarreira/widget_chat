"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/bridge/index.ts
var bridge_exports = {};
__export(bridge_exports, {
  ChatBridge: () => ChatBridge,
  ChatError: () => ChatError,
  ConversationRouter: () => ConversationRouter,
  formatFirstMessage: () => formatFirstMessage,
  formatFollowup: () => formatFollowup
});
module.exports = __toCommonJS(bridge_exports);

// src/bridge/router.ts
var GROUP_JID_SUFFIX = "@g.us";
var ConversationRouter = class {
  constructor(store) {
    this.store = store;
  }
  store;
  /**
   * `now` faz parte do contrato para que a bridge propague uma única leitura de relógio
   * por mensagem (touch/close/limite de horário nas próximas tasks); o router puro ainda
   * não a consome.
   */
  async decide(msg, now) {
    void now;
    let session = null;
    if (msg.jid.endsWith(GROUP_JID_SUFFIX)) {
      session = await this.store.getSessionByGroupJid(msg.jid);
    } else {
      const phone = msg.jid.split("@")[0] ?? "";
      if (phone.length === 0) return { action: "ignore" };
      session = await this.store.getSessionByVisitorPhone(phone);
    }
    if (session === null) return { action: "unknown_session" };
    if (await this.store.isEcho(session.id, msg.waMessageId)) return { action: "echo" };
    if (typeof msg.text !== "string" || msg.text.length === 0) return { action: "not_text" };
    const direction = msg.fromMe ? "owner" : "visitor";
    return { action: "route", session, direction, text: msg.text ?? "" };
  }
};

// src/bridge/format.ts
function formatFirstMessage(code, name, text) {
  return `\u{1F195} #${code} \u2014 ${name} (site):
${text}`;
}
function formatFollowup(name, text) {
  return `${name} (site): ${text}`;
}

// src/errors.ts
var ChatError = class extends Error {
  code;
  cause;
  constructor(message, code, cause) {
    super(message);
    this.name = "ChatError";
    this.code = code;
    this.cause = cause;
  }
};

// src/api/ids.ts
var SESSION_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
var SESSION_CODE_LENGTH = 4;
var SESSION_ACCEPT_LIMIT = 256 - 256 % SESSION_ALPHABET.length;
var BASE64URL_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
var TOKEN_BYTES = 24;
function randomChar(alphabet, acceptLimit) {
  const buffer = new Uint8Array(1);
  for (; ; ) {
    globalThis.crypto.getRandomValues(buffer);
    const byte = buffer[0];
    if (byte !== void 0 && byte < acceptLimit) {
      return alphabet.charAt(byte % alphabet.length);
    }
  }
}
function generateSessionCode() {
  return Array.from({ length: SESSION_CODE_LENGTH }, () => randomChar(SESSION_ALPHABET, SESSION_ACCEPT_LIMIT)).join("");
}
function generateRealtimeToken() {
  const bytes = new Uint8Array(TOKEN_BYTES);
  globalThis.crypto.getRandomValues(bytes);
  let token = "";
  let acc = 0;
  let bits = 0;
  for (const byte of bytes) {
    acc = acc << 8 | byte;
    bits += 8;
    while (bits >= 6) {
      bits -= 6;
      token += BASE64URL_ALPHABET.charAt(acc >>> bits & 63);
    }
  }
  return token;
}

// src/api/phone.ts
var NON_DIGITS = /\D+/g;
function normalizePhone(raw, defaultDdi = "55") {
  const digits = raw.replace(NON_DIGITS, "");
  if (!digits) throw new ChatError("Telefone vazio", "invalid_input");
  const explicitDdi = raw.includes("+");
  const withDdi = digits.length <= 11 && !explicitDdi && !digits.startsWith(defaultDdi) ? defaultDdi + digits : digits;
  if (withDdi.length < 10 || withDdi.length > 15) {
    throw new ChatError("Telefone inv\xE1lido", "invalid_input");
  }
  return withDdi;
}
function toWhatsappJid(phoneDigits) {
  return `${phoneDigits}@s.whatsapp.net`;
}

// src/api/webhook-parser.ts
function isRecord(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function textFromMessage(message) {
  if (!isRecord(message)) return null;
  const conversation = message["conversation"];
  if (typeof conversation === "string") {
    const trimmed = conversation.trim();
    return trimmed.length > 0 ? trimmed : null;
  }
  const extended = message["extendedTextMessage"];
  if (isRecord(extended)) {
    const text = extended["text"];
    if (typeof text === "string") {
      const trimmed = text.trim();
      return trimmed.length > 0 ? trimmed : null;
    }
  }
  return null;
}
function timestampSeconds(value) {
  const seconds = typeof value === "number" ? value : typeof value === "string" ? Number(value) : Number.NaN;
  return Number.isFinite(seconds) ? Math.floor(seconds) : 0;
}
function parseMessageItem(item) {
  if (!isRecord(item)) return { kind: "ignored", reason: "messages.upsert sem data v\xE1lido" };
  const key = isRecord(item["key"]) ? item["key"] : null;
  const waMessageId = key?.["id"];
  const jid = key?.["remoteJid"];
  if (typeof waMessageId !== "string" || waMessageId.length === 0) {
    return { kind: "ignored", reason: "mensagem sem key.id" };
  }
  if (typeof jid !== "string" || jid.length === 0) {
    return { kind: "ignored", reason: "mensagem sem key.remoteJid" };
  }
  const text = textFromMessage(item["message"]);
  if (text === null) {
    return { kind: "ignored", reason: "mensagem sem texto (conversation/extendedTextMessage)" };
  }
  const senderJid = key?.["participant"];
  return {
    kind: "message",
    event: {
      waMessageId,
      jid,
      fromMe: key?.["fromMe"] === true,
      senderJid: typeof senderJid === "string" ? senderJid : null,
      text,
      timestamp: timestampSeconds(item["messageTimestamp"]),
      raw: item
    }
  };
}
function parseWebhookEvent(payload) {
  if (!isRecord(payload)) return { kind: "ignored", reason: "payload n\xE3o \xE9 um objeto" };
  const event = payload["event"];
  if (typeof event !== "string") return { kind: "ignored", reason: "payload sem campo event" };
  const data = payload["data"];
  if (event === "connection.update") {
    const state = isRecord(data) ? data["state"] : void 0;
    if (typeof state === "string" && state.length > 0) return { kind: "connection", state };
    return { kind: "ignored", reason: "connection.update sem state" };
  }
  if (event === "group-participants.update") {
    return parseGroupParticipants(data);
  }
  if (event === "PRESENCE_UPDATE" || event === "presence.update") {
    return parsePresence(data);
  }
  if (event !== "messages.upsert") {
    return { kind: "ignored", reason: `evento n\xE3o tratado: ${event}` };
  }
  const items = Array.isArray(data) ? data : [data];
  let lastIgnored = { kind: "ignored", reason: "messages.upsert sem data v\xE1lido" };
  for (const item of items) {
    const parsed = parseMessageItem(item);
    if (parsed.kind !== "ignored") return parsed;
    lastIgnored = parsed;
  }
  return lastIgnored;
}
function parseGroupParticipants(data) {
  if (!isRecord(data)) return { kind: "ignored", reason: "group-participants sem data" };
  const groupJid = data["id"];
  if (typeof groupJid !== "string" || groupJid.length === 0) {
    return { kind: "ignored", reason: "group-participants sem id (groupJid)" };
  }
  const rawParticipants = data["participants"];
  if (!Array.isArray(rawParticipants)) {
    return { kind: "ignored", reason: "group-participants sem participants[]" };
  }
  const participants = [];
  for (const p of rawParticipants) {
    if (typeof p === "string" && p.length > 0) participants.push(p);
  }
  if (participants.length === 0) {
    return { kind: "ignored", reason: "group-participants sem participantes v\xE1lidos" };
  }
  const actionRaw = data["action"];
  const action = typeof actionRaw === "string" ? actionRaw : "unknown";
  const authorRaw = data["author"];
  const author = typeof authorRaw === "string" ? authorRaw : null;
  return {
    kind: "group_participants",
    event: { groupJid, participants, action, author, raw: data }
  };
}
function parsePresence(data) {
  if (!isRecord(data)) return { kind: "ignored", reason: "presence sem data" };
  const groupJid = typeof data["id"] === "string" && data["id"] ? data["id"] : null;
  let participantJid = null;
  let presenceRaw = null;
  const presences = data["presences"];
  if (isRecord(presences)) {
    const entries = Object.entries(presences);
    const first = entries[0];
    if (first !== void 0) {
      const [jid, info] = first;
      participantJid = jid;
      presenceRaw = isRecord(info) ? info["presence"] ?? info["lastKnownPresence"] : info;
    }
  } else {
    participantJid = typeof data["participant"] === "string" ? data["participant"] : null;
    presenceRaw = data["presence"] ?? data["lastKnownPresence"];
  }
  const presence = normalizePresence(presenceRaw);
  if (presence === null) return { kind: "ignored", reason: "presence sem estado reconhec\xEDvel" };
  return {
    kind: "presence",
    event: { groupJid, participantJid, presence, raw: data }
  };
}
function normalizePresence(value) {
  if (value === "composing" || value === "recording") return value;
  if (value === "paused") return "paused";
  if (value === "available" || value === "unavailable") return "paused";
  return null;
}

// src/bridge/bridge.ts
var NAME_MIN = 2;
var NAME_MAX = 60;
var MESSAGE_MIN = 1;
var MESSAGE_MAX = 1e3;
var RATE_LIMIT_WINDOW_MS = 10 * 60 * 1e3;
var RATE_LIMIT_MAX_SESSIONS = 5;
function honeypotSession(atIso) {
  return {
    id: "honeypot",
    code: "XXXX",
    realtimeToken: "",
    visitorName: "",
    visitorPhone: "",
    visitorContact: null,
    groupJid: null,
    status: "closed",
    createdAt: atIso,
    lastMessageAt: null
  };
}
function requireText(value, min, max, field) {
  const trimmed = typeof value === "string" ? value.trim() : "";
  if (trimmed.length < min || trimmed.length > max) {
    throw new ChatError(`${field} deve ter entre ${min} e ${max} caracteres`, "invalid_input");
  }
  return trimmed;
}
function isTargetGoneError(error) {
  if (error === null || typeof error !== "object") return false;
  const status = error.status;
  if (status === 404 || status === 410) return true;
  const text = `${String(error.message ?? "")} ${String(
    error.body ?? ""
  )}`.toLowerCase();
  return /group|participant|recipient|not found|unavailable|left|deleted|blocked|gone/.test(text);
}
var ChatBridge = class {
  constructor(deps) {
    this.deps = deps;
    this.router = new ConversationRouter(deps.store);
    this.clock = deps.clock ?? (() => /* @__PURE__ */ new Date());
  }
  deps;
  router;
  clock;
  config = null;
  /** Config injetada pelas rotas a cada request (setConfig → uso → getConfig). */
  getConfig() {
    if (this.config === null) {
      throw new ChatError("Chat n\xE3o configurado", "store_error");
    }
    return this.config;
  }
  setConfig(cfg) {
    this.config = cfg;
  }
  /**
   * Abre uma conversa: cria o grupo na Evolution, envia a primeira mensagem e persiste a
   * sessão. Não publica no canal realtime — quem abriu o chat já tem a própria mensagem.
   */
  async startChat(input) {
    const atIso = this.clock().toISOString();
    if (typeof input.honeypot === "string" && input.honeypot.trim().length > 0) {
      return { session: honeypotSession(atIso), messages: [] };
    }
    const name = requireText(input.name, NAME_MIN, NAME_MAX, "Nome");
    const message = requireText(input.message, MESSAGE_MIN, MESSAGE_MAX, "Mensagem");
    const phone = normalizePhone(input.phone);
    const cfg = this.getConfig();
    const store = this.deps.store;
    if (typeof input.ipHash === "string" && input.ipHash !== "") {
      const recent = await store.countRecentSessionsByIpHash(input.ipHash, RATE_LIMIT_WINDOW_MS);
      if (recent >= RATE_LIMIT_MAX_SESSIONS) {
        throw new ChatError(
          `Limite de ${RATE_LIMIT_MAX_SESSIONS} sess\xF5es por IP em 10 minutos excedido`,
          "rate_limited"
        );
      }
    }
    const existing = await store.getSessionByVisitorPhone(phone);
    if (existing !== null && existing.status === "active") {
      const firstTarget2 = existing.groupJid === null ? toWhatsappJid(normalizePhone(cfg.platformNumber)) : existing.groupJid;
      try {
        const { waMessageId: waMessageId2 } = await this.deps.client.sendText(
          cfg.instance,
          firstTarget2,
          formatFirstMessage(existing.code, name, message)
        );
        await store.registerSentMessageId(existing.id, waMessageId2);
        const initial2 = await store.appendMessage({
          sessionId: existing.id,
          direction: "visitor",
          body: message,
          waMessageId: waMessageId2,
          status: "sent"
        });
        return { session: existing, messages: [initial2] };
      } catch (error) {
        if (isTargetGoneError(error)) {
          await this.closeSessionCleanup(existing, "send_target_gone");
        } else {
          await store.markStatus(existing.id, "failed");
          throw new ChatError("Falha ao enviar a primeira mensagem para o grupo", "send_failed", error);
        }
      }
    }
    const code = generateSessionCode();
    const visitorJid = toWhatsappJid(phone);
    const platformJid = toWhatsappJid(normalizePhone(cfg.platformNumber));
    const participants = [.../* @__PURE__ */ new Set([visitorJid, platformJid])];
    const subject = `${cfg.projectName} \u2014 ${name} (#${code})`;
    const direct = cfg.createGroup === false;
    let groupJid = null;
    if (!direct) {
      groupJid = await this.createGroupWithRetry(cfg.instance, subject, participants, platformJid);
      const picture = (cfg.groupImage ?? "").trim();
      if (picture !== "") {
        try {
          await this.deps.client.setGroupPicture(cfg.instance, groupJid, picture);
        } catch {
        }
      }
    }
    const session = await store.createSession({
      code,
      realtimeToken: generateRealtimeToken(),
      visitorName: name,
      visitorPhone: phone,
      visitorContact: input.contact ?? null,
      groupJid,
      mode: direct ? "direct" : "group",
      ipHash: input.ipHash ?? null,
      userAgent: input.userAgent ?? null
    });
    let firstTarget;
    if (direct) {
      firstTarget = platformJid;
    } else {
      if (groupJid === null) throw new ChatError("Falha ao criar o grupo", "group_create_failed");
      firstTarget = groupJid;
    }
    let waMessageId;
    try {
      ({ waMessageId } = await this.deps.client.sendText(
        cfg.instance,
        firstTarget,
        formatFirstMessage(code, name, message)
      ));
    } catch (error) {
      await store.markStatus(session.id, "failed");
      throw new ChatError("Falha ao enviar a primeira mensagem para o grupo", "send_failed", error);
    }
    await store.registerSentMessageId(session.id, waMessageId);
    const initial = await store.appendMessage({
      sessionId: session.id,
      direction: "visitor",
      body: message,
      waMessageId,
      status: "sent"
    });
    return { session, messages: [initial] };
  }
  /** Relay site → grupo: persiste pending, envia, promove para sent (ou failed). */
  async sendVisitorMessage(token, text) {
    const cfg = this.getConfig();
    const { store } = this.deps;
    const session = await store.getSessionByToken(token);
    if (session === null) throw new ChatError("Sess\xE3o n\xE3o encontrada", "session_not_found");
    if (session.status !== "active") throw new ChatError("Sess\xE3o encerrada", "session_closed");
    const body = requireText(text, MESSAGE_MIN, MESSAGE_MAX, "Mensagem");
    let target;
    if (session.groupJid === null) {
      target = toWhatsappJid(normalizePhone(cfg.platformNumber));
    } else {
      target = session.groupJid;
    }
    const pending = await store.appendMessage({
      sessionId: session.id,
      direction: "visitor",
      body,
      status: "pending"
    });
    let waMessageId;
    try {
      ({ waMessageId } = await this.deps.client.sendText(
        cfg.instance,
        target,
        formatFollowup(session.visitorName, body)
      ));
    } catch (error) {
      await store.updateMessageStatus(pending.id, "failed");
      if (isTargetGoneError(error)) {
        await this.closeSessionCleanup(session, "send_target_gone", {
          systemMessage: "N\xE3o foi poss\xEDvel entregar a mensagem: o grupo n\xE3o est\xE1 mais dispon\xEDvel. Conversa encerrada \u2014 inicie uma nova para continuar."
        });
      }
      throw new ChatError("Falha ao enviar mensagem para o grupo", "send_failed", error);
    }
    await store.registerSentMessageId(session.id, waMessageId);
    await store.updateMessageStatus(pending.id, "sent");
    await store.touchSession(session.id, this.clock().toISOString());
    return { ...pending, status: "sent", waMessageId };
  }
  /**
   * Entrada do webhook da Evolution. NUNCA lança: um 500 aqui faz a Evolution reenviar
   * a mesma mensagem para sempre. Qualquer problema é logado e devolvido como não tratado.
   */
  async handleWebhook(payload) {
    try {
      const parsed = parseWebhookEvent(payload);
      if (parsed.kind === "group_participants") {
        return await this.handleGroupParticipants(parsed.event);
      }
      if (parsed.kind === "presence") {
        return await this.handlePresence(parsed.event);
      }
      if (parsed.kind !== "message") return { handled: false };
      const now = this.clock();
      const decision = await this.router.decide(parsed.event, now);
      if (decision.action !== "route") return { handled: false };
      const { session, direction, text } = decision;
      const waMessageId = parsed.event.waMessageId;
      const existing = await this.deps.store.findMessageByWaId(session.id, waMessageId);
      if (existing !== null) return { handled: true };
      const message = await this.deps.store.appendMessage({
        sessionId: session.id,
        direction,
        body: text,
        waMessageId,
        status: "sent"
      });
      await this.deps.store.touchSession(session.id, now.toISOString());
      await this.deps.transport.publish(session.realtimeToken, { type: "message", message });
      return { handled: true };
    } catch (error) {
      console.error("[evolution-chat] webhook n\xE3o processado:", error);
      return { handled: false };
    }
  }
  /**
   * Trata `group-participants.update` (Evolution): quando alguém entra, sai ou é
   * removido do grupo da sessão, registra uma mensagem de sistema no chat (visível
   * para visitante e time) e, se quem saiu foi o próprio visitante, encerra a sessão
   * — a conversa 1:1 pelo WhatsApp não chega mais pelo grupo.
   * NUNCA lança: qualquer erro é logado e devolvido como tratado (200) para a Evolution
   * não reenviar.
   */
  async handleGroupParticipants(change) {
    try {
      const session = await this.deps.store.getSessionByGroupJid(change.groupJid);
      if (session === null) return { handled: true };
      const phones = change.participants.map((jid) => jid.split("@")[0] ?? jid);
      const visitorLeft = change.participants.some((jid) => {
        const phone = jid.split("@")[0] ?? "";
        return phone !== "" && phone === session.visitorPhone;
      });
      let body;
      switch (change.action) {
        case "leave":
          body = `Participante(s) sa\xEDram do grupo: ${phones.join(", ")}`;
          break;
        case "remove":
          body = `Participante(s) removido(s) do grupo: ${phones.join(", ")}`;
          break;
        case "add":
          body = `Participante(s) adicionado(s) ao grupo: ${phones.join(", ")}`;
          break;
        case "promote":
          body = `Participante(s) promovido(s) a admin: ${phones.join(", ")}`;
          break;
        case "demote":
          body = `Participante(s) rebaixado(s) de admin: ${phones.join(", ")}`;
          break;
        default:
          body = `Altera\xE7\xE3o de participantes no grupo: ${phones.join(", ")}`;
      }
      const now = this.clock().toISOString();
      const message = await this.deps.store.appendMessage({
        sessionId: session.id,
        direction: "system",
        body,
        status: "sent"
      });
      await this.deps.store.touchSession(session.id, now);
      await this.deps.transport.publish(session.realtimeToken, { type: "message", message });
      if (visitorLeft) {
        await this.closeSessionCleanup(session, "visitor_left");
      }
      return { handled: true };
    } catch (error) {
      console.error("[evolution-chat] group-participants n\xE3o processado:", error);
      return { handled: true };
    }
  }
  /**
   * Trata `PRESENCE_UPDATE` (Evolution): quando a OUTRA ponta está digitando, publica
   * um evento de tempo real para o widget exibir os "3 pontinhos". O `from` distingue
   * quem digita (dona da plataforma vs. visitante) para o widget mostrar só quando a
   * ponta OPOSTA digita.
   * NUNCA lança: erros são logados e devolvidos como tratado (200) para a Evolution não
   * reenviar.
   */
  async handlePresence(event) {
    try {
      const cfg = this.getConfig();
      if (!cfg.enabled) return { handled: false };
      const session = event.groupJid !== null ? await this.deps.store.getSessionByGroupJid(event.groupJid) : null;
      if (session === null || session.status !== "active") return { handled: false };
      const isTyping = event.presence === "composing" || event.presence === "recording";
      const from = this.isPlatformParticipant(event.participantJid, cfg) ? "owner" : "visitor";
      await this.deps.transport.publish(session.realtimeToken, { type: "typing", isTyping, from });
      return { handled: true };
    } catch (error) {
      console.error("[evolution-chat] presence n\xE3o processado:", error);
      return { handled: true };
    }
  }
  /**
   * Sinaliza que o visitante está (ou parou de) digitar no widget. Publica um evento
   * `typing` no canal em tempo real da sessão para que uma eventual INTERFACE DE
   * ATENDENTE exiba o indicador.
   *
   * NOTA sobre WhatsApp: a Evolution só permite anunciar a presença da CONTA CONECTADA
   * à instância. Como o atendente desta plataforma OPERA a própria instância, enviar
   * `sendPresence` faria o widget exibir um "digitando" FALSO do atendente (eco do
   * próprio evento de volta pelo webhook). Por isso, aqui, apenas publicamos no canal
   * em tempo real — a presença WhatsApp do visitante não é representável por terceiros.
   */
  async setVisitorTyping(token, isTyping) {
    try {
      const session = await this.deps.store.getSessionByToken(token);
      if (session === null || session.status !== "active") return;
      await this.deps.transport.publish(session.realtimeToken, {
        type: "typing",
        isTyping,
        from: "visitor"
      });
    } catch (error) {
      console.warn("[evolution-chat] falha ao publicar presen\xE7a do visitante (ignorado):", error);
    }
  }
  /** Verdadeiro se `jid` é a conta da plataforma (dona da instância). */
  isPlatformParticipant(jid, cfg) {
    if (jid === null) return true;
    const platformJid = toWhatsappJid(normalizePhone(cfg.platformNumber));
    return jid === platformJid || jid === cfg.platformNumber || jid === `${cfg.platformNumber}@s.whatsapp.net`;
  }
  /**
   * Encerra a sessão (status closed + evento realtime) e — só quando o grupo morreu do
   * lado do visitante (ele saiu ou o destino sumiu) — faz a EMPRESA SAIR do grupo na
   * Evolution (best-effort) para não acumular grupos órfãos. Em fechamentos normais
   * (atendente encerrou a conversa) NÃO saímos: senão o visitante ficaria sozinho no grupo.
   */
  async closeSessionCleanup(session, reason, opts = {}) {
    const now = this.clock().toISOString();
    await this.deps.store.markStatus(session.id, "closed", reason);
    await this.deps.store.touchSession(session.id, now);
    if (opts.systemMessage !== void 0) {
      const notice = await this.deps.store.appendMessage({
        sessionId: session.id,
        direction: "system",
        body: opts.systemMessage,
        status: "sent"
      });
      await this.deps.transport.publish(session.realtimeToken, { type: "message", message: notice });
    }
    await this.deps.transport.publish(session.realtimeToken, { type: "session", status: "closed" });
    if (session.groupJid !== null && (reason === "visitor_left" || reason === "send_target_gone")) {
      try {
        await this.deps.client.leaveGroup(this.getConfig().instance, session.groupJid);
      } catch (error) {
        console.error("[evolution-chat] falha ao sair do grupo \xF3rf\xE3o:", error);
      }
    }
  }
  /** Replay para o widget: sessão por token + mensagens (opcionalmente após um ISO). */
  async history(token, afterIso) {
    const session = await this.deps.store.getSessionByToken(token);
    if (session === null) return { session: null, messages: [] };
    const messages = await this.deps.store.listMessages(session.id, afterIso);
    return { session, messages };
  }
  /**
   * createGroup com uma única retratação: um participante inválido (ex.: o número do
   * visitante, vindo de um formulário web) não pode abortar o atendimento — a segunda
   * tentativa cria o grupo só com a plataforma, o número que controlamos e é válido.
   *
   * Atenção (F1): createGroup NÃO é idempotente. Se a 1ª chamada criar o grupo e o erro
   * observado for um timeout, a retratação pode orfanar um segundo grupo; a compensação
   * (limpeza/reconciliação de órfãos) é preocupação das Tasks 7/8, não deste fix.
   */
  async createGroupWithRetry(instance, subject, participants, platformJid) {
    const attempts = participants.length > 1 ? [participants, [platformJid]] : [participants];
    let lastError;
    for (const attempt of attempts) {
      try {
        const { groupJid } = await this.deps.client.createGroup(instance, subject, attempt);
        return groupJid;
      } catch (error) {
        lastError = error;
      }
    }
    throw new ChatError("Falha ao criar o grupo na Evolution", "group_create_failed", lastError);
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ChatBridge,
  ChatError,
  ConversationRouter,
  formatFirstMessage,
  formatFollowup
});
//# sourceMappingURL=index.cjs.map