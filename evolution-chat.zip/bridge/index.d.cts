type ChatMessageDirection = "visitor" | "owner" | "system";
type ChatMessageStatus = "pending" | "sent" | "failed";
type ChatSessionStatus = "active" | "closed" | "failed";
/** Mensagem persistida (domínio). */
interface ChatMessage {
    id: string;
    sessionId: string;
    direction: ChatMessageDirection;
    body: string;
    status: ChatMessageStatus;
    waMessageId: string | null;
    createdAt: string;
}
/** Sessão de chat (um grupo do WhatsApp por visitante). */
interface ChatSession {
    id: string;
    code: string;
    realtimeToken: string;
    visitorName: string;
    visitorPhone: string;
    visitorContact: string | null;
    groupJid: string | null;
    /** Modo da conversa: "group" (grupo por visitante, padrão) ou "direct" (1:1 com a plataforma). */
    mode?: "group" | "direct";
    status: ChatSessionStatus;
    createdAt: string;
    lastMessageAt: string | null;
}
/**
 * Configuração resolvida da plataforma. Montada pelo consumidor (LMS) a partir
 * das settings e injetada no bridge via `setConfig`.
 */
interface ChatConfig {
    enabled: boolean;
    projectName: string;
    platformNumber: string;
    evolutionUrl: string;
    instance: string;
    apiKey: string;
    welcome: string;
    closeHours: number;
    leaveOnClose: boolean;
    webhookToken: string;
    /** true (padrão) = cria um grupo por visitante; false = conversa 1:1 direta com a plataforma. */
    createGroup?: boolean;
    /** URL pública da imagem de capa do grupo (opcional; ignora se vazia). */
    groupImage?: string;
}
/** Estado de presença (digitação) normalizado da Evolution. */
type PresenceState = "composing" | "paused" | "recording";
/** Evento de tempo real publicado no canal broadcast `chat:<realtimeToken>`. */
type ChatEvent = {
    type: "message";
    message: ChatMessage;
} | {
    type: "session";
    status: ChatSessionStatus;
}
/** Indicador de digitação: `from` diz quem está digitando (dona da plataforma
 *  ou visitante) para o widget exibir os "3 pontinhos" apenas quando a OUTRA
 *  ponta digita. */
 | {
    type: "typing";
    isTyping: boolean;
    from: "owner" | "visitor";
};
/**
 * Mensagem de entrada normalizada do webhook da Evolution, independente do
 * formato bruto do payload.
 */
interface InboundMessage {
    waMessageId: string;
    jid: string;
    fromMe: boolean;
    senderJid: string | null;
    text: string | null;
    timestamp: number;
    raw: unknown;
}

/** Persistência de sessões/mensagens vista pela bridge. */
interface SessionStore {
    createSession(input: {
        code: string;
        realtimeToken: string;
        visitorName: string;
        visitorPhone: string;
        visitorContact?: string | null;
        groupJid: string | null;
        /** Modo da conversa: "group" (padrão) ou "direct" (1:1 com a plataforma). Opcional. */
        mode?: "group" | "direct";
        /** Hash não-reversível do IP (LGPD): usado por countRecentSessionsByIpHash. */
        ipHash?: string | null;
        /** User-Agent bruto da requisição (auditoria/forense; nunca exibido). */
        userAgent?: string | null;
    }): Promise<ChatSession>;
    getSessionByToken(token: string): Promise<ChatSession | null>;
    getSessionByGroupJid(jid: string): Promise<ChatSession | null>;
    /** Lookup da sessão ativa de um visitante pelo telefone (modo direto 1:1). */
    getSessionByVisitorPhone(phone: string): Promise<ChatSession | null>;
    appendMessage(input: {
        sessionId: string;
        direction: ChatMessageDirection;
        body: string;
        waMessageId?: string | null;
        status?: ChatMessageStatus;
    }): Promise<ChatMessage>;
    /** Atualiza o status de uma mensagem já persistida (pending → sent/failed). */
    updateMessageStatus(id: string, status: ChatMessageStatus): Promise<void>;
    listMessages(sessionId: string, afterIso?: string | null): Promise<ChatMessage[]>;
    /**
     * Busca uma mensagem já persistida pelo `waMessageId` dentro da sessão (`null` se não
     * existir). Suporta a idempotência de reentrega do webhook: a Evolution reenvia a
     * mesma mensagem quando devolvemos `handled:false`, e o bridge precisa reconhecer o
     * duplicado em vez de anexar/publicar de novo.
     */
    findMessageByWaId(sessionId: string, waMessageId: string): Promise<ChatMessage | null>;
    /** Registra o waMessageId de uma mensagem enviada por ESTA instância (dedupe de eco). */
    registerSentMessageId(sessionId: string, waMessageId: string): Promise<void>;
    isEcho(sessionId: string, waMessageId: string): Promise<boolean>;
    touchSession(sessionId: string, atIso: string): Promise<void>;
    setGroupJid(sessionId: string, groupJid: string): Promise<void>;
    markStatus(sessionId: string, status: ChatSessionStatus, reason?: string): Promise<void>;
    countRecentSessionsByIpHash(ipHash: string, windowMs: number): Promise<number>;
}
/** Publicação server-side de eventos para o canal de uma sessão (fire-and-forget). */
interface RealtimeTransport {
    publish(realtimeToken: string, event: ChatEvent): Promise<void>;
}
/**
 * Assinatura client-side do mesmo canal (usada pelo widget — Task 9).
 * `subscribe` devolve o unsubscribe; `onStatus` reporta conexão do transporte.
 */
interface RealtimeHandle {
    subscribe(realtimeToken: string, onEvent: (e: ChatEvent) => void, onStatus?: (s: "open" | "closed") => void): () => void;
}
/** Injeção de relógio (testes determinísticos). */
type Clock = () => Date;
interface ChatLimiterResult {
    success: boolean;
}
/** Rate limiter (chave → janela). Implementações: memória, Redis, … */
type ChatLimiter = (key: string, limit: number, windowMs: number) => ChatLimiterResult | Promise<ChatLimiterResult>;
/**
 * Saída de ConversationRouter.decide — união discriminada por `action`: só o ramo
 * "route" carrega sessão/direção/texto (obrigatórios), eliminando o risco de
 * `decision.session` ser undefined em tempo de execução no consumidor (Task 6).
 *
 * Os `?: undefined` explícitos no 2º ramo preservam o typecheck de acessos sem
 * narrowing (ex.: `d.session` → `ChatSession | undefined` em testes já escritos);
 * após `if (d.action === "route")` os campos continuam obrigatórios.
 */
type RouterDecision = {
    action: "route";
    session: ChatSession;
    direction: ChatMessageDirection;
    text: string;
} | {
    action: "echo" | "unknown_session" | "not_text" | "ignore";
    session?: undefined;
    direction?: undefined;
    text?: undefined;
};

declare class ConversationRouter {
    private readonly store;
    constructor(store: Pick<SessionStore, "getSessionByGroupJid" | "getSessionByVisitorPhone" | "isEcho">);
    /**
     * `now` faz parte do contrato para que a bridge propague uma única leitura de relógio
     * por mensagem (touch/close/limite de horário nas próximas tasks); o router puro ainda
     * não a consome.
     */
    decide(msg: InboundMessage, now: Date): Promise<RouterDecision>;
}

/** Primeira mensagem da conversa no grupo: destaca código, nome e quebra de linha. */
declare function formatFirstMessage(code: string, name: string, text: string): string;
/** Demais mensagens vindas do site: prefixo curto na mesma linha. */
declare function formatFollowup(name: string, text: string): string;

interface SendTextResult {
    waMessageId: string;
}
interface CreateGroupResult {
    groupJid: string;
}
interface EvolutionClient {
    sendText(instance: string, number: string, text: string): Promise<SendTextResult>;
    /** Envia presença de digitação ("digitando…") para o número/grupo. `presence` =
     *  "composing" | "recording" (digitando) ou "paused" (parou). Best-effort: a
     *  presença é anunciada pela CONTA CONECTADA à instância, não por terceiros. */
    sendPresence(instance: string, number: string, presence: PresenceState): Promise<void>;
    createGroup(instance: string, subject: string, participants: string[], description?: string): Promise<CreateGroupResult>;
    setGroupPicture(instance: string, groupJid: string, image: string): Promise<void>;
    leaveGroup(instance: string, groupJid: string): Promise<void>;
    /** Encerra a sessão WhatsApp da instância (desvincula o dispositivo). */
    logout(instance: string): Promise<void>;
    getConnectionState(instance: string): Promise<"open" | "connecting" | "close">;
    connectQR(instance: string): Promise<{
        qrBase64: string | null;
        pairingCode: string | null;
    }>;
    setWebhook(instance: string, url: string, events: string[]): Promise<void>;
    /** Cria a instância na Evolution (one-time). Exige a apiKey com permissão de criação. */
    createInstance(instance: string, integration?: "WHATSAPP-BAILEYS" | "WHATSAPP-BUSINESS"): Promise<void>;
    /**
     * Garante que a instância existe (idempotente): se `getConnectionState` responde
     * (qualquer estado), não faz nada; só chama `createInstance` quando a leitura falha
     * (instância inexistente). Assim o LMS gerencia o ciclo de vida sem criar manualmente
     * na Evolution — o único passo humano é escanear o QR de pareamento.
     */
    ensureInstance(instance: string): Promise<void>;
}

interface StartChatInput {
    name: string;
    phone: string;
    message: string;
    contact?: string | null;
    ipHash?: string | null;
    userAgent?: string | null;
    honeypot?: string | null;
}
interface ChatBridgeDeps {
    client: EvolutionClient;
    store: SessionStore;
    transport: RealtimeTransport;
    /** Relógio injetável (testes determinísticos). Default: `() => new Date()`. */
    clock?: Clock;
}
declare class ChatBridge {
    private readonly deps;
    private readonly router;
    private readonly clock;
    private config;
    constructor(deps: ChatBridgeDeps);
    /** Config injetada pelas rotas a cada request (setConfig → uso → getConfig). */
    getConfig(): ChatConfig;
    setConfig(cfg: ChatConfig): void;
    /**
     * Abre uma conversa: cria o grupo na Evolution, envia a primeira mensagem e persiste a
     * sessão. Não publica no canal realtime — quem abriu o chat já tem a própria mensagem.
     */
    startChat(input: StartChatInput): Promise<{
        session: ChatSession;
        messages: ChatMessage[];
    }>;
    /** Relay site → grupo: persiste pending, envia, promove para sent (ou failed). */
    sendVisitorMessage(token: string, text: string): Promise<ChatMessage>;
    /**
     * Entrada do webhook da Evolution. NUNCA lança: um 500 aqui faz a Evolution reenviar
     * a mesma mensagem para sempre. Qualquer problema é logado e devolvido como não tratado.
     */
    handleWebhook(payload: unknown): Promise<{
        handled: boolean;
    }>;
    /**
     * Trata `group-participants.update` (Evolution): quando alguém entra, sai ou é
     * removido do grupo da sessão, registra uma mensagem de sistema no chat (visível
     * para visitante e time) e, se quem saiu foi o próprio visitante, encerra a sessão
     * — a conversa 1:1 pelo WhatsApp não chega mais pelo grupo.
     * NUNCA lança: qualquer erro é logado e devolvido como tratado (200) para a Evolution
     * não reenviar.
     */
    private handleGroupParticipants;
    /**
     * Trata `PRESENCE_UPDATE` (Evolution): quando a OUTRA ponta está digitando, publica
     * um evento de tempo real para o widget exibir os "3 pontinhos". O `from` distingue
     * quem digita (dona da plataforma vs. visitante) para o widget mostrar só quando a
     * ponta OPOSTA digita.
     * NUNCA lança: erros são logados e devolvidos como tratado (200) para a Evolution não
     * reenviar.
     */
    private handlePresence;
    /**
     * Sinaliza que o visitante está (ou parou de) digitar no widget. Publica um evento
     * `typing` no canal em tempo real da sessão para que uma eventual INTERFACE DE
     * ATENDENTE exiba o indicador.
     *
     * NOTA sobre WhatsApp: a Evolution só permite anunciar a presença da CONTA CONECTADA
     * à instância. Como o atendente desta plataforma OPERA a própria instância, enviar
     * `sendPresence` faria o widget exibir um "digitando" FALSO do atendente (eco do
     * próprio evento de volta pelo webhook). Por isso, aqui, apenas publicamos no canal
     * em tempo real — a presença WhatsApp do visitante não é representável por terceiros.
     */
    setVisitorTyping(token: string, isTyping: boolean): Promise<void>;
    /** Verdadeiro se `jid` é a conta da plataforma (dona da instância). */
    private isPlatformParticipant;
    /**
     * Encerra a sessão (status closed + evento realtime) e — só quando o grupo morreu do
     * lado do visitante (ele saiu ou o destino sumiu) — faz a EMPRESA SAIR do grupo na
     * Evolution (best-effort) para não acumular grupos órfãos. Em fechamentos normais
     * (atendente encerrou a conversa) NÃO saímos: senão o visitante ficaria sozinho no grupo.
     */
    private closeSessionCleanup;
    /** Replay para o widget: sessão por token + mensagens (opcionalmente após um ISO). */
    history(token: string, afterIso?: string | null): Promise<{
        session: ChatSession | null;
        messages: ChatMessage[];
    }>;
    /**
     * createGroup com uma única retratação: um participante inválido (ex.: o número do
     * visitante, vindo de um formulário web) não pode abortar o atendimento — a segunda
     * tentativa cria o grupo só com a plataforma, o número que controlamos e é válido.
     *
     * Atenção (F1): createGroup NÃO é idempotente. Se a 1ª chamada criar o grupo e o erro
     * observado for um timeout, a retratação pode orfanar um segundo grupo; a compensação
     * (limpeza/reconciliação de órfãos) é preocupação das Tasks 7/8, não deste fix.
     */
    private createGroupWithRetry;
}

type ChatErrorCode = "invalid_input" | "rate_limited" | "group_create_failed" | "send_failed" | "session_not_found" | "session_closed" | "disabled" | "unauthorized" | "store_error" | "webhook_invalid";
declare class ChatError extends Error {
    readonly code: ChatErrorCode;
    readonly cause?: unknown;
    constructor(message: string, code: ChatErrorCode, cause?: unknown);
}

export { ChatBridge, type ChatBridgeDeps, ChatError, type ChatErrorCode, type ChatEvent, type ChatLimiter, type ChatLimiterResult, type ChatMessage, type ChatMessageDirection, type ChatMessageStatus, type ChatSession, type ChatSessionStatus, type Clock, ConversationRouter, type RealtimeHandle, type RealtimeTransport, type RouterDecision, type SessionStore, type StartChatInput, formatFirstMessage, formatFollowup };
